
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;
import java.util.Arrays;

import static java.util.Collections.list;

public class Main {
    static void basicMenu() {
        System.out.println("---------------------------------\n");
        System.out.println("1. Enter in a new movie\n");
        System.out.println("2. Reserve a ticket + seat\n");
        System.out.println("3. Get a ticket (random seat)\n");
        System.out.println("4. Add movies/customers via .txt file\n");
        System.out.println("5. Remove movies\n");
        System.out.println("6. Remove a customer\n");
        System.out.println("7. Print all movies and customer info\n");
        System.out.println("-1. Quit\n");
    }

    static void main(String[] args) {
        Scanner myObj = new Scanner(System.in);
        Scanner myObj2 = new Scanner(System.in);
        Scanner myObj3 = new Scanner(System.in);
        Scanner myObj4 = new Scanner(System.in);
        Scanner myObj5 = new Scanner(System.in);
        Scanner myObj6 = new Scanner(System.in);
        Scanner myObj7 = new Scanner(System.in);
        ArrayList<Movie> list = new ArrayList();
        int menuOption = 777, Idee=0, Iddd=0,zeekeeper=0, rando=0,movieCounter=0,answer=0;
        double taxx = 0;
        String DX=" ",DK,daMovie=" ", firstAnswer = "yes", secondAnswer = "yes",zeanswer=" ";
        boolean seatChecker = true, validEntry=false, emptyChecker=false;

        //System.out.println("Enter in the first movie's name: ");

/// /////////////////////////////////////////////////////////////////
        while (!validEntry) {
            System.out.println("Enter in the first movie's name: ");
            if (myObj.hasNextLine()) {
                daMovie = myObj.nextLine();
                validEntry=true;
            } else {
                System.out.println("That's not an answer, try again. (Enter letters/characters, and spaces should be separated with _s) ");
                myObj.nextLine();
            }
        }
        validEntry=false;
        while (!validEntry) {
            System.out.println("Enter in the first movie's tax rate: ");
            if (myObj.hasNextDouble()) {
                taxx = myObj.nextDouble();
              //  myObj.nextLine();
                validEntry = true;
            } else {
                System.out.println("Not an answer, please enter numbers: ");
                myObj.next();
            }
        }
        validEntry = false;
        while (!validEntry) {
            System.out.println("Enter in how many seats the first movie has: ");
            if (myObj.hasNextInt()) {
                Idee= myObj.nextInt();
                myObj.nextLine();
                if(Idee>0) {
                    validEntry = true;
                    list.add(0, new Movie("", new int[Idee], taxx, new String[Idee], new boolean[Idee], new String[Idee]));
                    //Makes sure all seats are available(true)
                    Arrays.fill(list.get(0).isFilled, true);
                    Arrays.fill(list.get(0).CustomerName, " ");
                    Arrays.fill(list.get(0).CustomerAge, " ");
                    list.get(0).title = daMovie;
                    list.get(movieCounter).setTitle(daMovie);
                }
                else{
                    System.out.println("Dude, enter a positive.\n");
                    Idee=0;
                }
            }
          /*  else if(myObj.hasNextInt()){
                System.out.println("Not an answer, please enter whole positive numbers: ");
                myObj.next();

            }*/
           /* else if (myObj.nextInt()<0){
                System.out.println("Not an answer, please enter whole positive numbers: ");
                myObj.next();
                myObj.nextLine();
            }*/
            else {
                System.out.println("Not an answer, please enter whole positive numbers: ");
                myObj.next();
                myObj.nextLine();
            }
        }
        validEntry=false;

        /*while (true) {
            // Display message
            System.out.println("Enter in how much is the tax rate of first movie: ");
            taxx = Double.parseDouble(myObj.next());

            // Try block to check if any exception occurs
            try {
                // Parsing user input to double
                // Get off from this loop
                break;
            }
            // Catch block to handle NumberFormatException
            catch (NumberFormatException e) {
                // Print the message if exception occurred
                System.out.println(
                        "NumberFormatException occurred (enter a number)\n");
            }
        }

        while (true) {
            // Display message
            System.out.println("\nEnter in how many seats the first movie's theater has: ");
            Idee = Integer.parseInt(myObj.next());

            // Try block to check if any exception occurs
            try {
                // Parsing user input to integer
                // using the parseInt() method
                list.add(new Movie(daMovie, new int[Idee], taxx, new String[Idee], new boolean[Idee], new String[Idee]));
                //Makes sure all seats are available(true)
                Arrays.fill(list.get(0).isFilled,true);
                Arrays.fill(list.get(0).CustomerName," ");
                list.get(0).title=daMovie;
                // Get off from this loop
                break;
            }
            // Catch block to handle NumberFormatException
            catch (NumberFormatException e) {
                // Print the message if exception occurred
                System.out.println(
                        "\nNumberFormatException occurred (enter a number)\n");
            }
        }*/

/// ///////////////////////////////////////////////////////////////////////////////
        basicMenu();
        System.out.println("Enter an numbered option or -1 to quit:");
        menuOption = Integer.parseInt(myObj.next());


        //Coding for all of the options
        while (menuOption != -1) {
            switch (menuOption) {
                //first option
                case 1:
                    int x = 0;
                    //Infinite loop of asking for movies to enter

                    for (; x != -1; ++x) {
                        //counter for moving up in the movie arraylist for later
                        movieCounter++;
                        //System.out.println("Enter the name of the movie into the program: ");
                        // DX = myObj.next();
                        validEntry=false;
                        //Infinitely ask for movies to enter, catching any non-answers

                        while (!validEntry) {
                            System.out.println("Enter in the name of the movie into the program: ");
                            if (myObj2.hasNextLine()) {
                                DX=myObj2.nextLine();
                                validEntry=true;
                            } else {
                                System.out.println("That's not an answer, try again. (Enter letters/characters, and spaces should be seperated with _s) ");
                                myObj2.nextLine();
                            }
                        }
                        validEntry=false;

                        /*while (!validEntry) {
                            System.out.println("Enter the name of the movie into the program: ");
                            // Display message
                            if (myObj.hasNextLine()) {
                                DX = myObj.nextLine();
                                validEntry = true;
                            } else {
                                System.out.println("Not an answer, please enter letters and numbers, and separate spaces with _s: ");
                                myObj.next();
                            }
                        }*/
                            // Try block to check if any exception occurs
                           /* try {
                                // Parsing user input to double
                                // Get off from this loop
                                break;
                            }
                            // Catch block to handle NumberFormatException
                            catch (NumberFormatException e) {
                                // Print the message if exception occurred
                                System.out.println(
                                        "\nNumberFormatException occurred (enter a number)\n");
                            }*/

                        validEntry=false;
                        //System.out.println("Enter in how much is the tax rate of first movie: ");
                        // taxx = Double.parseDouble(myObj.next());
                        //Infinitely ask for tax rates, catching any non-answers
                        while (!validEntry) {
                            System.out.println("Enter in how much is the tax rate of first movie: ");
                            if (myObj2.hasNextDouble()) {
                                taxx = myObj2.nextDouble();
                                myObj2.nextLine();
                                validEntry = true;
                            } else {
                                System.out.println("Not an answer, please enter numbers: ");
                                myObj2.next();
                            }
                        }
                            // Try block to check if any exception occurs
                            /*try {
                                // Parsing user input to integer
                                // using the parseInt() method
                                // Get off from this loop
                                break;
                            }
                            // Catch block to handle NumberFormatException
                            catch (NumberFormatException e) {
                                // Print the message if exception occurred
                                System.out.println(
                                        "\nNumberFormatException occurred (enter a number)\n");
                            }*/


                        validEntry=false;
                        //Infinitely asks for numbers of seats in the theater, catch any non-answers
                        while (!validEntry) {
                            System.out.println("Enter in how many seats the movie's theater has: ");
                            if(myObj2.hasNextInt()){
                                Iddd = myObj2.nextInt();
                                myObj2.nextLine();
                              //  myObj2.nextLine();
                                if(Iddd>0){
                                    validEntry=true;
                                }
                                else{
                                    System.out.println("You want to watch a movie for a nonexistent theater? Try again.\n ");
                                }
                            }
                            else{
                                System.out.println("Not an answer, please enter numbers: ");
                                myObj2.next();
                               // myObj.nextLine();
                            }
                            // Try block to check if any exception occurs
                            /*try {
                                // Parsing user input to integer
                                // using the parseInt() method
                                // Get off from this loop
                                break;
                            }
                            // Catch block to handle NumberFormatException
                            catch (NumberFormatException e) {
                                // Print the message if exception occurred
                                System.out.println(
                                        "\nNumberFormatException occurred (enter a number)\n");
                            }*/
                        }
                        validEntry=false;
                        //System.out.println("Enter in how many seats the movie's theater has: ");
                        // Iddd = Integer.parseInt(myObj.next());

                        //Makes a new entry in the movie arraylist, all bits of logic depend on the number of seats
                        list.add(movieCounter,new Movie(DX+"", new int[Iddd], taxx, new String[Iddd], new boolean[Iddd], new String[Iddd]));

                        // list.add(new Movie(new String, new int[Iddd], taxx, new String[Iddd], new boolean[Iddd], new String[Iddd]));

                        // list.get(movieCounter).setTitle(DX);

                        //Makes sure that the new movie's seats are all available by default
                        Arrays.fill(list.get(movieCounter).getIsFilled(),true);
                        //Makes sure names are blank by default
                        Arrays.fill(list.get(movieCounter).CustomerName," ");
                        //And all the customer's ages
                        Arrays.fill(list.get(movieCounter).CustomerAge," ");

                        // list.get(movieCounter).setTitle(DX);

                        // list.get(movieCounter).setTitle(DX);
                        // list.get(0).setTitle(daMovie);

                        //Asks if user wants to keep entering in movies, catches any non-answers
                        while (!validEntry) {
                            System.out.println("Do you want to continue entering in movies? (enter -1 if not, enter any other number if yes): ");
                            if (myObj.hasNextInt()) {
                                answer = myObj.nextInt();
                                validEntry = true;
                            } else {
                                System.out.println("Not an answer, please enter numbers: ");
                                myObj.next();
                            }
                        }
                        // System.out.println("Do you want to continue entering in movies? (enter -1 if not, enter any other number if yes): ");
                        // int answer = myObj.nextInt();

                        if (answer == -1) {
                            //If yes, breaks loop
                            x = -2;
                            System.out.println("------------------------------------- ");
                            basicMenu();
                            System.out.println("Enter an numbered option or -1 to quit:");
                            menuOption = Integer.parseInt(myObj.next());
                        }
                    }

                    //Prints everything
                    for (int y = 0; y < list.size(); ++y) {
                        list.get(y).starterPrint();
                    }
                    break;
/////////////////////////////////////////////////////////////////////////////////////////////////////
                //Option 2
                case 2:
                    boolean leerror=false;

                    // System.out.println("Enter the name of the movie you wish to reserve for: ");
                    // String zeanswer = myObj.next();



                  //Makes sure you entered a valid input for what Movie you want to reserve a spot, stores input if it is
                    validEntry=false;
                        while (!validEntry) {
                            System.out.println("Enter the name of the movie you wish to reserve for: ");
                            if (myObj3.hasNextLine()) {
                               zeanswer = myObj3.nextLine();
                                validEntry = true;
                            } else {
                                System.out.println("That's not an answer, try again. (Enter letters/characters) ");
                                myObj3.nextLine();
                            }
                        }
                        validEntry=false;
                        //Checks if that Movie is available or not
                        for ( int g = list.size() - 1; g >= 0; --g) {
                            //Makes full error message only pop up once

                            //If it finds it and there's seats available then...
                            if (((Movie) list.get(g)).noSeats(seatChecker) == true) {
                                if (((Movie) list.get(g)).title.equals(zeanswer)) {
                                    list.get(g).idkMan();

                                    //Asks for what seat number you'd like, looping til valid entry is permitted
                                    while (!validEntry) {
                                        System.out.println("\nEnter what number seat you'd like to reserve (must be more than 0 and whole number and must be a number available in the theater): ");
                                        if (myObj3.hasNextInt()) {
                                            zeekeeper = myObj3.nextInt() - 1;
                                            myObj3.nextLine();

                                            //Makes sure the seat number isn't a negative or taken seat or else loops back around

                                            if (zeekeeper >= 0) {
                                                if(list.get(g).seatNum.length>zeekeeper && list.get(g).isFilled[zeekeeper]==true) {
                                                    leerror=true;
                                                    validEntry = true;
                                                }
                                                else if(list.get(g).seatNum.length<zeekeeper){
                                                    System.out.println("\nSorry, we don't have that number of seat available. Try again");
                                                }
                                            } else if (zeekeeper < 0 || list.get(g).isFilled[zeekeeper]==false) {
                                                System.out.println("\nPlease enter a whole number and make sure it isn't taken!\n ");
                                            }
                                            //If user enters non answer then outputs this and asks again
                                        } else {
                                            System.out.println("Not an answer, please enter numbers: ");
                                            myObj3.next();
                                        }
                                    }
                                    validEntry = false;
                                    //Infinitely ask for whole numbers
                                /*while (true) {
                                    // Display message
                                    //Whatever seat number you're entered under will dictate later logic for the Movie arraylist
                                    System.out.println("\nEnter what number seat you'd like to reserve: ");
                                    zeekeeper = Integer.parseInt(myObj.next()) - 1;
                                    if (zeekeeper < 0) {
                                        System.out.println("\nPlease enter a whole number!\n ");
                                        System.out.println("\nEnter what number seat you'd like to reserve: ");
                                        zeekeeper = Integer.parseInt(myObj.next());
                                    }

                                    // Try block to check if any exception occurs
                                    try {*/
                                    // Parsing user input to double
                                    // Get off from this loop

                                    //Saves name user inputs
                                    ((Movie) list.get(g)).isFilled[zeekeeper] = false;
                                    System.out.println("\nWhat name would you like to be reserved under?");
                                    String urName = myObj3.nextLine();
                                    ((Movie) list.get(g)).CustomerName[zeekeeper] = urName;
                                    System.out.println("\n Then you will be reserved under " + urName + "!");

                                    //Asks for acceptable age til user enters obliges
                                    System.out.println("\nWhat age are you? (C,A,S)");
                                    DK = myObj3.next();
                                    myObj3.nextLine();

                                    //Enter your age,checks if it's c/a/s
                                    for (int a = 1; a < 100; a--) {
                                        if (DK.equals("c") == true || DK.equals("C") == true
                                                || DK.equals("a") == true || DK.equals("A") == true
                                                || DK.equals("s") == true || DK.equals("S") == true) {
                                            a = 200;
                                            list.get(g).CustomerAge[zeekeeper] = DK;
                                        }
                                        //Else gives this error message and makes you try again
                                        else if (DK.equals("c") == false || DK.equals("C") == false
                                                || DK.equals("a") == false || DK.equals("A") == false
                                                || DK.equals("s") == false || DK.equals("S") == false) {
                                            System.out.println("That is not an accepted answer, please enter your age:(C,A,S)");
                                            DK = myObj3.next();
                                            myObj3.nextLine();
                                        }
                                    }
                                    //Determines your ticket cost and what age you're registered as
                                    if (DK.equals("c") || DK.equals("C")) {
                                        System.out.println("\n That will be $" + (((1 + (list.get(g).taxRate)) * 8)));
                                        list.get(g).CustomerAge[zeekeeper] = "C";
                                        leerror=true;
                                    }
                                    if (DK.equals("a") || DK.equals("A")) {
                                        System.out.println("\n That will be $" + (((1 + list.get(g).taxRate)) * 12));
                                        list.get(g).CustomerAge[zeekeeper] = "A";
                                        leerror=true;
                                    }
                                    if (DK.equals("s") || DK.equals("S")) {
                                        System.out.println("\n That will be $" + (((1 + list.get(g).taxRate)) * 10));
                                        list.get(g).CustomerAge[zeekeeper] = "S";
                                        leerror=true;
                                    }
                                    System.out.println("--------------------------------------------------\n");

                                   // break;
                                }
                                // Catch block to handle NumberFormatException
                                   /* catch (NumberFormatException e) {
                                        // Print the message if exception occurred
                                        System.out.println(
                                                "NumberFormatException occurred (enter a whole number)\n");
                                    }*/


                            }

                            //Otherwise just prints a generic message
                            else {
                                System.out.println("\nThat's not a movie registered in the system!");
                            }
                       // }

                    }
                    //Checks if there's no seats left, if so....
                            if (leerror == false) {
                    System.out.println("Sorry, that movie is full, please try another movie.");
                }

                    //Calls back the menu as part of the infinite loop
                    basicMenu();
                    System.out.println("Enter an numbered option or -1 to quit:");
                    menuOption = Integer.parseInt(myObj.next());
                    break;

/// ////////////////////////////////////////////////////////////////////////////////////////////////
                //Third option
                case 3:
                    //Random ticket = new Random();
                    System.out.println("Enter the name of the movie you wish to buy your ticket for: ");
                    zeanswer = myObj4.nextLine();

                    //Goes through entire Movie arraylist to try and find the movie name you entered
                    for (int l = list.size() - 1; l >= 0; --l)  {
                        //if it finds it then....
                        if (((Movie) list.get(l)).title.equals(zeanswer)) {
                            //First makes sure that there's seats available
                            for (int o = 0; o < list.get(l).seatNum.length; o++) {
                                if (list.get(l).noSeats(seatChecker) == true) {
                                    //If there is then...
                                    list.get(l).idkMan();

                                    //Loop to calculate your random ticket number, going til you get one unavailable
                                    for (int f = 0; f < 100; f--) {
                                        int index = (int) (Math.random() * list.get(l).seatNum.length);
                                        if (list.get(l).isFilled[index] == true) {
                                            rando = index;
                                            list.get(l).isFilled[index] = false;
                                            f = 200;
                                        }
                                    }
                                    System.out.println("Your seat is number " + (rando + 1));
                                    //listt(l).isFilled[rando+1]=false;

                                    System.out.println("\nWhat age are you? (C,A,S)");
                                    DK = myObj4.next();
                                    myObj4.nextLine();
                                    //Enter your age, checks if it's c/a/s
                                    for (int a = 1; a < 100; a--) {
                                        if (DK.equals("c") == true || DK.equals("C") == true
                                                || DK.equals("a") == true || DK.equals("A") == true
                                                || DK.equals("s") == true || DK.equals("S") == true) {
                                            a = 200;
                                            list.get(l).CustomerAge[rando] = DK;
                                        }
                                        //Else gives this error message and makes you try again
                                        else if (DK.equals("c") == false || DK.equals("C") == false
                                                || DK.equals("a") == false || DK.equals("A") == false
                                                || DK.equals("s") == false || DK.equals("S") == false) {
                                            System.out.println("That is not an accepted answer, please enter your age:(C,A,S)");
                                            DK = myObj4.next();
                                            myObj4.nextLine();
                                        }
                                    }
                                    //Determines your ticket cost and what age you're registered as
                                    if (DK.equals("c") || DK.equals("C")) {
                                        System.out.println("\n That will be $" + (((1 + list.get(l).taxRate)) * 8));
                                        System.out.println("------------------------------------- ");
                                        list.get(l).CustomerAge[l] = "C";
                                        o= list.get(l).seatNum.length+10;

                                    }
                                    if (DK.equals("a") || DK.equals("A")) {
                                        System.out.println("\n That will be $" + (((1 + list.get(l).taxRate)) * 12));
                                        System.out.println("------------------------------------- ");
                                        list.get(l).CustomerAge[l] = "A";
                                        o=list.get(l).seatNum.length+10;

                                    }
                                    if (DK.equals("s") || DK.equals("S")) {
                                        System.out.println("\n That will be $" + (((1 + list.get(l).taxRate)) * 10));
                                        System.out.println("------------------------------------- ");
                                        list.get(l).CustomerAge[l] = "S";
                                        o=list.get(l).seatNum.length+10;
                                    }

                                }
                                //Otherwise, error message
                                else{
                                    System.out.println(" Sorry, there's no more seats available\n");
                                }
                                //If there's no such movie in the system produces this message
                                if (!list.get(l).title.equals(zeanswer)) {
                                    System.out.println("Sorry that's not in our system\n");
                                }
                            }

                        }
                    }

                    System.out.println("------------------------------------- ");
                    basicMenu();
                    System.out.println("Enter an numbered option or -1 to quit:");
                    menuOption = Integer.parseInt(myObj.next());

                    break;

                    /// ///////////////////////////////////////////////////////////////////////////////////////
                //Option 4
                case 4:
                    //User enters their .txt file directory
                    System.out.println("WARNING! Please make sure your .txt file is in name-number of seats-tax rate-customer name/customer age format first\n");
                    System.out.println("Enter the directory path of the .txt file you want to use ");
                    String txt = myObj5.next();

                    try {
                        FileInputStream fstream = new FileInputStream(txt);
                        DataInputStream in = new DataInputStream(fstream);
                        BufferedReader br = new BufferedReader(new InputStreamReader(in));

                        String strLine;
                        //Stores info into strings to break apart til end of file
                        while((strLine = br.readLine()) != null) {
                            //Stores into...
                            int size=-1;
                            String[] goodStuff= new String[]{("")};
                            double daTax=0;

                            //Ignores negatives
                            if(!strLine.contains("--")) {

                                //Part that ignores the dashes

                                 goodStuff = strLine.split("-");

                           /* for (int e = 0; e < goodStuff.length; e++) {
                                System.out.println(goodStuff[e] + ", ");
                            }*/
                                 size = 0;
                                String leName = goodStuff[0];

                                //An entry is just ignored if there's no seats
                                if (Integer.parseInt(goodStuff[1]) > 0) {
                                    size = Integer.parseInt(goodStuff[1]);
                                }
                                 daTax = Double.parseDouble(goodStuff[2]);
                            }

                            if (size > 0) {
                                //Adds to movie arraylist if it passed the checks
                                list.add(new Movie(goodStuff[0], new int[size], daTax, new String[size], new boolean[size], new String[size]));
                                movieCounter++;
                                //Fills the info with blanks by default
                                Arrays.fill(list.get(movieCounter).isFilled, true);
                                Arrays.fill(list.get(movieCounter).CustomerName, " ");

                                int Custcounter = 0;

                                //Separates the /s into readable info, and puts it into the arraylist
                                for (int m = 3; m < goodStuff.length; ++m) {
                                    String[] slopslop = goodStuff[m].split("/");
                                    String Nozomi = slopslop[0], Eito = slopslop[1];
                                    //for(int p=0;p< goodStuff.length;p++){
                                    if (Custcounter < list.get(movieCounter).seatNum.length) {

                                        list.get(movieCounter).isFilled[Custcounter] = false;
                                        list.get(movieCounter).CustomerName[Custcounter] = Nozomi;
                                        if (Eito.equals("c") || Eito.equals("C") || Eito.equals("a")
                                                || Eito.equals("A") || Eito.equals("s") || Eito.equals("S")) {
                                            list.get(movieCounter).CustomerAge[Custcounter] = Eito;
                                        } else {
                                            list.get(movieCounter).CustomerAge[Custcounter] = "A";
                                        }
                                        //list.get(movieCounter).setCustomerName(Nozomi);
                                        // list.get(movieCounter).setCustomerAge(Eito);
                                        // }
                                        Custcounter++;
                                    }
                                }
                            }
                        }

                        in.close();
                        System.out.println("Entered. Please note any movies with 0 or less and bonus customers with full houses were also excluded.\n");
                    } catch (IOException e) {
                        e.printStackTrace();
                    }

                    for(int y = 0; y < list.size(); ++y) {
                        ((Movie)list.get(y)).starterPrint();
                    }

                    // System.out.println("Do you want to continue or go back to main menu? (-1 for main menu, any other number for continue):");
                    // int response = myObj.nextInt();
                    // if (response == -1) {
                    basicMenu();
                    System.out.println("Enter an numbered option or -1 to quit:");
                    menuOption = myObj.nextInt();
                    System.out.println("------------------------------------------");
                    //  break;
                    //  }
                    break;
/// //////////////////////////////////////////////////////////////////////////////////////////////////////////////
                //Option 5
                case 5:
                    //Infinitely asks for movies to delete
                    for(int b=0;b<100;b--){
                        //Assuming there's anything to delete that is or else
                        if(list.size()>0) {

                            //Asks what to delete
                            System.out.println("What movie do you want to erase?: ");
                            String dee = myObj6.nextLine();

                            //Checks if it's in the system
                            // if(list.size()>=0) {
                            for (int k = list.size() - 1; k >= 0; --k) {
                                //If it is then delete
                                if (((Movie) list.get(k)).title.equals(dee)) {
                                    list.remove(k);
                                    System.out.println(dee+ " has been removed\n ");
                                    emptyChecker=true;
                                    movieCounter--;
                                }
                            }
                            //If not then error message
                            if (emptyChecker=false){
                                System.out.println("That's not a movie in the system!\n ");
                            }
                            emptyChecker=false;
                        }
                        //Error if no movies are in
                        else{
                            System.out.println("There are currently no movies in the system, please enter one in first.\n ");
                        }

                        //Asks if user wants to continue entering movies, breaks loop if no
                        System.out.println("Do you want to stop entering Movies?(yes/no)");
                        String daanswer = myObj6.nextLine();
                        // daanswercheck = Double.parseDouble(daanswer);
                        if (daanswer.equals("yes") || daanswer.equals("Yes")){
                            b=200;
                        }
                        else if (daanswer.equals("no") || daanswer.equals("No")){
                        }
                        else{
                            System.out.println("Not an answer! Now do you want to stop entering Movies?(yes/no)");
                            daanswer = myObj.next();
                            myObj.nextLine();
                        }
                    }

                    for (int y = 0; y < list.size(); ++y) {
                        ((Movie) list.get(y)).starterPrint();
                    }
                    basicMenu();
                    System.out.println("Enter an numbered option or -1 to quit:");
                    menuOption = Integer.parseInt(myObj.next());
                    break;
//////////////////////////////////////////////////////////////////////////////////////////
                //Option 6
                case 6:
                    int leet=0;

                    for(int b=0;b<100;b--){
                        boolean error=true;

                        //Asks for Movie to delete customer from
                        System.out.println("What movie do you want to erase a customer from?: ");
                        String dee = myObj7.nextLine();
                        int availacounter=0;

                        //Scans database to see if user input is in or not
                        if(list.size()>=0) {
                            for (int k = list.size() - 1; k >= 0; --k) {
                                if (((Movie) list.get(k)).title.equals(dee)) {
                                    for(int u=0;u<list.get(k).seatNum.length;u++) {
                                        if(list.get(k).isFilled[u]==false){
                                            availacounter++;
                                        }
                                    }

                                    ((Movie) list.get(k)).starterPrint();
                                    validEntry=false;

                                    //Makes sure a seat number to remove is entered. Gives error if not.
                                    while (!validEntry) {
                                        System.out.println("Enter the seat number of the customer you'd like to remove (must be within the specified range): ");

                                        if(myObj7.hasNextInt()){
                                            leet = myObj7.nextInt();
                                            myObj7.nextLine();
                                           leet --;

                                           //Checks if there's any customers to be deleted or not, otherwise produces a message and gets you out of loop
                                           if(availacounter>1) {

                                               //Makes sure user enters seat numbers in range, if so deletes customer
                                               if (list.get(k).seatNum.length > leet && leet>=0) {
                                                       list.get(k).isFilled[leet] = true;
                                                       list.get(k).CustomerName[leet] = "";
                                                       list.get(k).CustomerAge[leet] = "";
                                                       System.out.println("seat number: " + (leet + 1) + " has been removed\n ");
                                                       validEntry = true;
                                                       error=false;
                                               } else {
                                                   System.out.println("That seat number doesn't seem to be in the system\n");
                                               }
                                           }
                                           //No customers message
                                           else{
                                               System.out.println("There are no customers registered, please register some first then come back\n");
                                               validEntry=true;
                                           }

                                        }
                                        //If user enters something not allowed loops back around
                                        else{
                                            System.out.println("Not an answer, please enter whole numbers numbers: ");
                                            myObj7.next();
                                            myObj7.nextLine();
                                        }
                                    }
                                    validEntry=false;

                                }
                            }
                             if(error==true){
                                System.out.println("That's not a movie in the system!\n ");
                                error=false;
                            }
                        }
                        //No Movies to delete anything from message
                        else{
                            System.out.println("There are currently no movies in the system, please enter one in first.\n ");
                        }

                        //Breaks loop if you don't want to continue, asks for customers infinitely if you do.
                        System.out.println("Do you want to stop entering Movies?(yes/no)");
                        String daanswer = myObj7.next();
                        myObj7.nextLine();
                        // daanswercheck = Double.parseDouble(daanswer);
                        if (daanswer.equals("yes") || daanswer.equals("Yes")){
                            b=200;
                        }
                        else if (daanswer.equals("no") || daanswer.equals("No")){
                        }
                        else{
                            System.out.println("Not an answer! Now do you want to stop entering Movies?(yes/no)");
                            daanswer = myObj7.next();
                            myObj7.nextLine();
                        }
                    }

                    basicMenu();
                    System.out.println("Enter an numbered option or -1 to quit:");
                    menuOption = Integer.parseInt(myObj.next());
                    break;

/// //////////////////////////////////////////////////////////////
            //Option 7
                case 7:
                    for (int y = 0; y < list.size(); ++y) {
                        ((Movie) list.get(y)).starterPrint();
                    }
                    basicMenu();
                    System.out.println("Enter an numbered option or -1 to quit:");
                    menuOption = Integer.parseInt(myObj.next());

                    break;


                case -1:
                    break;

                default:
                    basicMenu();
                    System.out.println("\nThat's not an option! Enter an numbered option or -1 to quit:");
                    menuOption = myObj.nextInt();

            }

        }
    }
}

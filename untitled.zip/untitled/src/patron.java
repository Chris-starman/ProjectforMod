//Represents a patron and all of their info

public class patron {
    //starts the info patron has, their ID, fines, names and addresses
    int ID;
    double fine;
    String title, address;
    public patron(int ID, double fine, String title, String address){
        this.ID=ID;
        this.fine=fine;
        this.title=title;
        this.address=address;

    }
    //dafault stuff in case things go wrong
public patron(){
        this.ID=0;
        this.fine=0;
        this.title="Not registered";
        this.address="Not registered";
}
    //getters and setters
    public String getNname(){

        return title;
    }
    public void setName(String name){

        this.title=title;
    }
    public String getAddress(){

        return address;
    }
    public void setAddress(String name){

        this.address=address;
    }
     public int getID(){

        return ID;
    }
    public double getFine(){
        return fine;
    }

    //Print the patron's registered info
    public void starterPrint() {
        System.out.println("User ID: " + ID +
                "\nfine: $" + fine + "\nName: " +title+ "\nAddress: " +address);
    }



}


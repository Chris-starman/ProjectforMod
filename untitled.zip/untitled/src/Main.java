import java.util.ArrayList;
import java.util.Scanner;
import java.io.File;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

//keep Main() clean by keeping the menu system's options a function

void  basicMenu() {

    System.out.println("1. Enter patron information into program\n");
    System.out.println("2. Remove patron by ID number\n");
    System.out.println("3. List all patrons\n");
    System.out.println("4. Add patrons via .txt file\n");
    System.out.println("-1. Quit\n");
}

void main() {
//defines the arraylist storing the patron and the menu options (done with numbers)
    Scanner myObj = new Scanner(System.in);
    ArrayList <patron> list = new ArrayList<patron>();
    int menuOption=777;

    basicMenu();
    System.out.println("Enter an numbered option or -1 to quit:");
    menuOption = myObj.nextInt();

//The part of the menu that keeps doing options til you quit
while(menuOption != -1) {

    switch (menuOption) {
        //enter patron info
        case 1:
//really just a basic loop to keep asking for patron info til -1 is entered.
// Puts info in arraylist
            for (int x = 0; x != -1; x++) {
                System.out.println("Enter patron's ID into program: ");
                int Idee = myObj.nextInt();

                System.out.println("Enter the patron's fine into program (between $0-250): ");
                double faine = myObj.nextDouble();
                while (faine < 0 || faine > 250) {
                    System.out.println("Enter the patron's fine into program (between $0-250): ");
                    faine = myObj.nextDouble();
                }
                System.out.println("Enter the patron's first name into program: ");
                String lame = myObj.next();
                System.out.println("Enter the patron's last name into program: ");
                String insane = myObj.next();
                System.out.println("Enter the patron's address into program: ");
                String address = myObj.next();
                //adds the variables to a single element of the arraylist
                list.add(new patron(Idee, faine, (lame + " " + insane), address));
                //breaks the loop
                System.out.println("Do you want to continue entering patrons? (enter -1 if not, enter any other number if yes): ");
                int answer = myObj.nextInt();
                if (answer == -1) {
                    x = -2;
                }
            }
//prints loop results when done
            for (int y = 0; y < list.size(); y++) {
                list.get(y).starterPrint();
            }
            break;
//erasing a patron via ID option
        case 2:
            //asks once before proceeding
            System.out.println("Do you want to erase a patron's info?(-1 for no, any other number for yes):");
            int daanswer = myObj.nextInt();
            //The part that asks forever and ever
            while (daanswer != -1) {
                System.out.println("Enter the ID number of the patron you wish to erase: ");
                int dee = myObj.nextInt();
                //the part that erases the set of patron info (their arraylist element)
                for (int k = list.size() - 1; k >= 0; k--) {
                    if (list.get(k).ID == dee) {
                        list.remove(k);
                    }
                }
                //Ask again using response
                System.out.println("Do you want to erase a patron's info?(-1 for no, any other number for yes):");
                daanswer = myObj.nextInt();
            }
//prints it all out
            for (int y = 0; y < list.size(); y++) {
                list.get(y).starterPrint();
            }
            break;
        //print entire patron arraylist
        case 3:
            for (int y = 0; y < list.size(); y++) {
                list.get(y).starterPrint();
            }
            break;
        case 4:
            //scans from an txt file (in this case mod3.txt, which should be attached
            try {
                // Open the file
                FileInputStream fstream = new FileInputStream("mod3.txt");

// Get the info
                DataInputStream in = new DataInputStream(fstream);
                BufferedReader br = new BufferedReader(new InputStreamReader(in));

                String strLine;

//Reads line by line
                while ((strLine = br.readLine()) != null) {
                    int first;
                    double second;
                    String third, fourth;
                    //Gets rid of the dash
                    String[] goodStuff = strLine.split("-");
                    for (int m = 0; m < 4; m++) {
                        first = Integer.parseInt(goodStuff[0]);
                        second = Double.parseDouble(goodStuff[1]);
                        third = goodStuff[2];
                        fourth = goodStuff[3];
                        if (m == 3) {
                            list.add(new patron(first, second, third, fourth));
                        }
                    }

                }

//Close the input stream
                in.close();

            } catch (IOException e) {
                // Handle potential I/O errors (e.g., file not found)
                e.printStackTrace();
            }

//prints it all out
            for (int y = 0; y < list.size(); y++) {
                list.get(y).starterPrint();
            }
            break;
    }
        //Continue message
        System.out.println("Do you want to continue? (-1 for no, any other number for yes):");
        int response = myObj.nextInt();
        //makes or breaks loop
        if(response != -1){
            basicMenu();
            System.out.println("Enter an numbered option or -1 to quit:");
             menuOption = myObj.nextInt();
        }

   }
}

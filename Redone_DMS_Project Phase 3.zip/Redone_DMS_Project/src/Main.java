
import javax.swing.*;
import java.io.BufferedReader;
 import java.io.DataInputStream;
import java.io.FileInputStream;
 import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.Arrays;
import java.awt.*;
import java.awt.event.*;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class Main extends JPanel{
    static void basicMenu() {
        System.out.println("---------------------------------\n");
        System.out.println("1. Enter in a new movie\n");
        System.out.println("2. Reserve a ticket + seat\n");
        System.out.println("3. Get a ticket (random seat)\n");
        System.out.println("4. Add movies/customers via .txt file\n");
        System.out.println("5. Remove movies\n");
        System.out.println("6. Remove a customer\n");
        System.out.println("7. Print all movies and customer info\n");
        System.out.println("-1. Quit\n");
    }

    static void main(String[] args) {
        Scanner myObj = new Scanner(System.in);
        Scanner myObj2 = new Scanner(System.in);
        Scanner myObj3 = new Scanner(System.in);
        Scanner myObj4 = new Scanner(System.in);
        Scanner myObj5 = new Scanner(System.in);
        Scanner myObj6 = new Scanner(System.in);
        Scanner myObj7 = new Scanner(System.in);
        ArrayList<Movie> list = new ArrayList();
        int menuOption = 777;
        int Idee=0;
        int Iddd=0;
        int zeekeeper=0;
        int rando=0;
        final int[] movieCounter = {-1};
        int answer=0;
        final int[] Yunaka = { 0 };
        double taxx = 0;
        String DX=" ",DK,daMovie=" ", firstAnswer = "yes", secondAnswer = "yes",zeanswer=" ";
        boolean seatChecker = true, validEntry=false, emptyChecker=false;


        //System.out.println("Enter in the first movie's name: ");
       /* SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                jFrame frame1= new jFrame();
            }
        });*/

//Defines the pop-up menu
        Frame peace= new Frame("DMS Project");
        //peace.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        MenuBar menuBar = new MenuBar();
        peace.setMenuBar(menuBar);

        //peace.getContentPane().setLayout(new FlowLayout());




        // Create a "File" menu
        Menu fileMenu = new Menu("Options");
        MenuItem newItem = new MenuItem("Put movie in the system");
        MenuItem ApplyItem = new MenuItem("Register for a movie seat of your choice");
        MenuItem randomItem = new MenuItem("Register for a random seat for a movie");
        MenuItem TxtItem = new MenuItem("Register movies/seats via .txt file");
        MenuItem DelItem = new MenuItem("Delete a movie");
        MenuItem LeetItem = new MenuItem("Remove a seat");
        MenuItem PrintItem = new MenuItem("Print everything in the system");
        JLabel instructions = new JLabel("Welcome. Please use the menu above to get started. Minimize and maximize the page to load in the option when selected");

        /// //////////////////////////////////////////////////
        //First Menu Option, adding a movie in

            newItem.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    //Define everything that'll be use panel-wise
                    JPanel panel1 = new JPanel();

                    JLabel Bylabel = new JLabel("Please enter name of the movie");
                    JTextField MovieEnter = new JTextField(10);
                    MovieEnter.setToolTipText("Type in the movie's name here. Press enter whenever you're done.");
                    JTextField SeatEnter = new JTextField(10);
                    JLabel Byseat = new JLabel("Please Enter in how many seats the theater houses");
                    SeatEnter.setToolTipText("Type in how many seats the theater has here. Must be more than 0");
                    JTextField TaxEnter = new JTextField(10);
                    JLabel ByTax = new JLabel("\nPlease Enter in how much the tax rate is");
                    JButton wonder =new JButton("Enter movie in");
                    JLabel FYI = new JLabel("");
                    JLabel FYI2 = new JLabel("");

                    String movieman = "";
                    double lifecost = 0;
                    final int[] Pyracushion = {0};
                    //MovieEnter.setEnabled(true);
                    //SeatEnter.setEnabled(true);
                    //TaxEnter.setEnabled(true);


                    //Shows off the text field and labels, being entering in the movie
                    peace.removeAll();
                    peace.setVisible(true);
                    //peace.removeAll();
                    peace.add(panel1);
                    panel1.add(Bylabel);
                    panel1.add(MovieEnter);
                    panel1.add(Byseat);
                    panel1.add(SeatEnter);
                    panel1.add(ByTax);
                    panel1.add(TaxEnter);
                    panel1.add(wonder);
                    panel1.add(FYI);
                    panel1.add(FYI2);


                    //When you press the button do...
                    wonder.addActionListener(new ActionListener() {
                        @Override
                        public void actionPerformed(ActionEvent e) {
                            // int thingforthestuff=list.size();
                           // Pyracushion[0] = Integer.parseInt(SeatEnter.getText());
                            String movieman =MovieEnter.getText().trim();
                            //Double lifecost= Double.parseDouble(ByTax.getText())
                            // Checks if the parameters are empty
                            if(movieman.isEmpty()){
                                JOptionPane.showMessageDialog(null, "Hey dude, put something here", "You didn't even try", JOptionPane.ERROR_MESSAGE);
                                return;
                            }
                            //Makes sure the user enters a number
                                String input=SeatEnter.getText().trim();
                                if(input.isEmpty()){
                                    JOptionPane.showMessageDialog(null, "Hey dude, put something here", "You didn't even try", JOptionPane.ERROR_MESSAGE);
                                    return;
                                }
                                try{
                                    int Pyracushion = Integer.parseInt(input);
                                    //One more than 0 at that
                                    if(Pyracushion>0){
                                        String input2=TaxEnter.getText().trim();
                                        if (input2.isEmpty()){
                                            JOptionPane.showMessageDialog(null, "Hey dude, put something here", "You didn't even try", JOptionPane.ERROR_MESSAGE);
                                            return;
                                        }
                                        try{
                                            double lifecost=Double.parseDouble(input2);
                                            if(lifecost>0){
                                                //If you do, put it into the movie arraylist
                                                int thingforthestuff=list.size();
                                                list.add(new Movie("", new int[Pyracushion], lifecost, new String[Pyracushion], new boolean[Pyracushion], new String[Pyracushion]));
                                                Arrays.fill(list.get(thingforthestuff).isFilled, true);
                                                Arrays.fill(list.get(thingforthestuff).CustomerName, " ");
                                                Arrays.fill(list.get(thingforthestuff).CustomerAge, " ");
                                                list.get(thingforthestuff).title = movieman;
                                                FYI.setText("Ok, " + movieman + ", seating  " + Pyracushion + ", at  " + lifecost + " tax rate has been entered.");
                                                MovieEnter.setText("");
                                                SeatEnter.setText("");
                                                TaxEnter.setText("");
                                                FYI2.setText("If you would like to add more movies just enter your text and press the button again");
                                            }
                                            //Various error messages in case the user enters something in wrong
                                            else{
                                                JOptionPane.showMessageDialog(null, "No Government would ever give negative taxes, put a positive",
                                                        "Bruh", JOptionPane.ERROR_MESSAGE);

                                            }
                                        }catch(NumberFormatException k){
                                            JOptionPane.showMessageDialog(null, "Not a number", "C'mon man", JOptionPane.ERROR_MESSAGE);
                                        }
                                    }
                                    else{
                                        JOptionPane.showMessageDialog(null, "You want to watch a movie in a theater with nonexistent seats? Try again",
                                                "Bruh", JOptionPane.ERROR_MESSAGE);
                                    }

                                }catch(NumberFormatException op){
                                    JOptionPane.showMessageDialog(null, "Not a number", "C'mon man", JOptionPane.ERROR_MESSAGE);
                                }

                               /* if (SeatEnter.getText().trim().equals("") || MovieEnter.getText().trim().equals("") || ByTax.getText().trim().equals("")) {
                                    JOptionPane.showMessageDialog(null, "Hey dude, put something here", "You didn't even try", JOptionPane.ERROR_MESSAGE);
                                }
                                if (Pyracushion[0] <= 0 || lifecost <= 0) {
                                    JOptionPane.showMessageDialog(null, "You want to watch movies for a nonexistent theater? Try again", "Nice", JOptionPane.ERROR_MESSAGE);
                                }
                                if(Pyracushion[0] >0==true && lifecost>0==true){
                                    list.add(new Movie("", new int[Pyracushion[0]], lifecost, new String[Pyracushion[0]], new boolean[Pyracushion[0]], new String[Pyracushion[0]]));
                                    Arrays.fill(list.get(thingforthestuff).isFilled, true);
                                    Arrays.fill(list.get(thingforthestuff).CustomerName, " ");
                                    Arrays.fill(list.get(thingforthestuff).CustomerAge, " ");
                                    list.get(thingforthestuff).title = movieman;
                                    FYI.setText("Ok, " + movieman + ", seating  " + Pyracushion[0] + ", at  " + lifecost + " tax rate has been entered.");
                                    MovieEnter.setText("");
                                    SeatEnter.setText("");
                                    TaxEnter.setText("");
                                    FYI2.setText("If you would like to add more movies just enter your text and press the button again");
                                }*/
                            }
                    });
                    // MovieEnter.setText("");

                    //Whenever user hits enter puts up the second label and text field, being the number of seats
                   /*MovieEnter.addActionListener(new ActionListener() {
                        String movieman = "";
                        double lifecost = 0;
                        int Pyracushion = 0;

                        @Override
                        public void actionPerformed(ActionEvent e) {
                            movieman = "";
                            movieman = MovieEnter.getText();
                            // MovieEnter.setText("");
                            panel1.add(Box.createVerticalStrut(20));
                            panel1.add(Byseat);
                            panel1.add(SeatEnter);
                            peace.setVisible(true);
                            peace.add(panel1);
                           // MovieEnter.setEnabled(false);
                           // SeatEnter.setEnabled(true);
                            // SeatEnter.setText("");

                            //Whenever user hits enter there too puts up 3rd label and text field (tax rate) and makes sure seat number >0
                            SeatEnter.addActionListener(new ActionListener() {
                                @Override
                                public void actionPerformed(ActionEvent e) {
                                    String inputStr = SeatEnter.getText().trim();
                                    if (inputStr.isEmpty()) {
                                        JOptionPane.showMessageDialog(null, "Hey dude, put something here", "You didn't even try", JOptionPane.ERROR_MESSAGE);
                                        return;
                                    }

                                    try {
                                        Pyracushion = 0;
                                        Pyracushion = Integer.parseInt(inputStr);
                                        if (Pyracushion > 0) {

                                            panel1.add(ByTax);
                                            panel1.add(TaxEnter);
                                            peace.setVisible(true);
                                            peace.add(panel1);
                                            //SeatEnter.setEnabled(false);
                                          // TaxEnter.setEnabled(true);
                                            //TaxEnter.setText("");

                                            //Whenever user hits enter puts up last entry stuff, the tax rate
                                            TaxEnter.addActionListener(new ActionListener() {
                                                @Override
                                                public void actionPerformed(ActionEvent e) {
                                                    String inputStr = TaxEnter.getText().trim();
                                                    if (inputStr.isEmpty()) {
                                                        JOptionPane.showMessageDialog(null, "Enter a number", "Error", JOptionPane.ERROR_MESSAGE);
                                                        return;
                                                    }

                                                    try {

                                                        double lifecost = Double.parseDouble(inputStr);
                                                        if (lifecost > 0) {
                                                            //TaxEnter.setEnabled(false);
                                                            int thingforthestuff = list.size();


                                                            list.add(new Movie("", new int[Pyracushion], lifecost, new String[Pyracushion], new boolean[Pyracushion], new String[Pyracushion]));
                                                            //Makes sure all seats are available(true)
                                                            Arrays.fill(list.get(thingforthestuff).isFilled, true);
                                                            Arrays.fill(list.get(thingforthestuff).CustomerName, " ");
                                                            Arrays.fill(list.get(thingforthestuff).CustomerAge, " ");
                                                            //Yunaka[0]++;
                                                            list.get(thingforthestuff).title = movieman;
                                                            //list.get(movieCounter).setTitle(movieman);

                                                            JLabel onresult = new JLabel("Ok, " + movieman + ", seating  " + Pyracushion + ", at  " + lifecost + " tax rate has been entered.");
                                                            JLabel request = new JLabel("Would you like to continue adding in movies?");
                                                            panel1.add(onresult);
                                                            peace.setVisible(true);
                                                            peace.add(panel1);

                                                            //   MovieEnter.setText("");
                                                            // SeatEnter.setText("");
                                                            //  TaxEnter.setText("");

                                                        } else {
                                                            // Input is a non-positive double
                                                            JOptionPane.showMessageDialog(null, "Please enter a positive value above 0", "Error", JOptionPane.ERROR_MESSAGE);
                                                        }
                                                    } catch (NumberFormatException ex) {
                                                        // Input is not a number
                                                        JOptionPane.showMessageDialog(null, "Please put a number", "Ya Dun Goofed", JOptionPane.ERROR_MESSAGE);
                                                    }
                                                }

                                            });

                                        } else {
                                            // Input is a non-positive double
                                            JOptionPane.showMessageDialog(null, "Enter a positive number, please", "You messed up", JOptionPane.ERROR_MESSAGE);
                                        }
                                    } catch (NumberFormatException ex) {
                                        // Input is not a number
                                        JOptionPane.showMessageDialog(null, "That's not an acceptable answer. Please enter a whole number", "You messed up", JOptionPane.ERROR_MESSAGE);
                                    }

                    /*boolean  validEntry=false;
                      while (!validEntry) {
                          if (myObj.hasNextDouble()) {
                              lifecost = myObj.nextDouble();
                              //  myObj.nextLine();
                              validEntry = true;
                          } else {
                              System.out.println("Not an answer, please enter numbers: ");
                              myObj.next();
                          }
                      }
                                }
                            });
                        }

                    });*/
                }
            });
        /// /////////////////////////////////////////////////
        //Second option in the menu (Getting a seat choice)
        ApplyItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //Defines panel things to be used
                JPanel panel2 = new JPanel();

                JLabel Yourmovie = new JLabel("Please enter name of the movie you'd like to watch");
                JTextField MovieEnter = new JTextField(10);
                MovieEnter.setToolTipText("Type in the movie's name here. Press enter whenever you're done.");
                JTextField SeatEnter = new JTextField(10);
                SeatEnter.setToolTipText("Type in the movie's name here. Press enter whenever you're done.");
                JLabel Yourseat = new JLabel("Please enter what seat number you'd like");
                JTextField AgeEnter = new JTextField(10);
                AgeEnter.setToolTipText("Type in the movie's name here. Press enter whenever you're done.");
                JLabel Yourage = new JLabel("Please enter in how old you are (C/A/S)");
                JTextField NameEnter = new JTextField(10);
                NameEnter.setToolTipText("Type in the movie's name here. Press enter whenever you're done.");
                JLabel Yourname = new JLabel("Please enter in your name");
                JButton fates= new JButton("Enter");
                JLabel availaset= new JLabel("");
                String movieman = "";
                double lifecost = 0;

                Yourmovie.setEnabled(true);
                Yourage.setEnabled(true);
                Yourseat.setEnabled(true);


                //Shows off the first text field and label, being entering in the movie
                peace.setVisible(true);
                peace.removeAll();
                peace.add(panel2);
                panel2.add(Yourmovie);
                panel2.add(MovieEnter);
                panel2.add(Yourseat);
                panel2.add(SeatEnter);
                panel2.add(Yourname);
                panel2.add(NameEnter);
                panel2.add(Yourage);
                panel2.add(AgeEnter);

                panel2.add(fates);
                panel2.add(availaset);
                // MovieEnter.setText("");
                //When you press the button do...

                fates.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        //Makes sure the user enters in a number more than 0
                        String ginput=SeatEnter.getText().trim();
                        if(ginput.isEmpty()){
                            JOptionPane.showMessageDialog(null, "Hey dude, put something here", "You didn't even try", JOptionPane.ERROR_MESSAGE);
                            return;
                        }
                        try {
                            boolean pizzapizza=true;
                           int Euniecushion=Integer.parseInt(ginput);
                           if(Euniecushion>0){
                               //Makes sure the strings are filled, error messages if not
                               String N=MovieEnter.getText().trim();
                               if(N.isEmpty()){
                                   JOptionPane.showMessageDialog(null, "Don't leave me hanging, enter something", "Hey! Listen!", JOptionPane.ERROR_MESSAGE);
                               }
                               String M=AgeEnter.getText().trim();
                               if(M.isEmpty()){
                                   JOptionPane.showMessageDialog(null, "Don't leave me hanging, enter something", "Hey! Listen!", JOptionPane.ERROR_MESSAGE);
                               }
                               if (M.equals("A")==true || M.equals("a")==true  || M.equals("c")==true || M.equals("C")==true  || M.equals("s")==true || M.equals("S")==true) {

                                   String sena = NameEnter.getText().trim();
                                   //Checks if there's available seats/movies or not
                                   boolean fillchecker = false, anyChecker=false;
                                   Euniecushion--;
                                   //Goes through entire Movie arraylist to try and find the movie name you entered
                                   for (int g = list.size() - 1; g >= 0; --g) {
                                       if (((Movie) list.get(g)).noSeats(pizzapizza) == true) {
                                           if (((Movie) list.get(g)).title.equals(N)) {
                                               anyChecker=true;
                                               //If there is, put it in movie arraylist
                                               if (list.get(g).isFilled[Euniecushion] == true) {
                                                   list.get(g).isFilled[Euniecushion] = false;
                                                   list.get(g).CustomerAge[Euniecushion] = M;
                                                   list.get(g).CustomerName[Euniecushion] = sena;
                                                   if (M.equals("c") || M.equals("C")) {
                                                       availaset.setText("Ok " + sena + ", your seat at " + N + " is seat number " + (Euniecushion + 1) +
                                                               ", you have been registered under a child ticket. Your total is $" + (list.get(g).taxRate * 8));
                                                   }
                                                   if (M.equals("a") || M.equals("A")) {
                                                       availaset.setText("Ok " + sena + ", your seat at " + N + " is seat number " + (Euniecushion + 1) +
                                                               ", you have been registered under an adult ticket. Your total is $" + (list.get(g).taxRate * 12));
                                                   }
                                                   if (M.equals("s") || M.equals("S")) {
                                                       availaset.setText("Ok " + sena + ", your seat at " + N + " is seat number " + (Euniecushion + 1) +
                                                               ", you have been registered under a senior ticket. Your total is $" + (list.get(g).taxRate * 10));
                                                   }
                                                   fillchecker = true;
                                               }
                                           }
                                           //Various error messages in case user enters wrong info

                                       } else if (list.get(g).noSeats(pizzapizza) == false) {
                                           JOptionPane.showMessageDialog(null, "Sorry, man. That movie is full.", "Womp womp", JOptionPane.ERROR_MESSAGE);
                                       } else if (list.size() <= 0) {
                                           JOptionPane.showMessageDialog(null, "There's nothing in the system, go enter a movie in first", "Womp womp", JOptionPane.ERROR_MESSAGE);
                                       } else {
                                           JOptionPane.showMessageDialog(null, "Seems you didn't enter something in the system, go try again.", "Womp womp", JOptionPane.ERROR_MESSAGE);
                                       }
                                   }
                                   if (fillchecker == false) {
                                       JOptionPane.showMessageDialog(null, "Either that seat isn't in the system or is already taken, enter another", "You're too slow!", JOptionPane.ERROR_MESSAGE);
                                   }
                                   if (anyChecker == false) {
                                       JOptionPane.showMessageDialog(null, "That movie isn't in the system, try again", "Hey, c'mon c'mon", JOptionPane.ERROR_MESSAGE);
                                   }

                                   fillchecker = false;
                               }
                               else{
                                   JOptionPane.showMessageDialog(null, "You're not a fetus. Enter whether (C)hild,(A)dult,or (S)enior", "Ok, Tiki", JOptionPane.ERROR_MESSAGE);
                               }


                              /* if(Euniecushion>0) {
                                   if(M.equals("A")||M.equals("a")||M.equals("c")|!M.equals("C")||M.equals("s")||M.equals("S")) {
                                   for (int s = list.size() - 1; s >= 0; s--) {
                                       if (list.get(s).isFilled[Euniecushion] == true) {
                                           list.get(s).isFilled[Euniecushion] = false;
                                           list.get

                                       } else {
                                           JOptionPane.showMessageDialog(null, "That seat is taken, sorry", "You're too slow!", JOptionPane.ERROR_MESSAGE);
                                       }
                                     }
                                    }
                               }*/




                           }
                           else{
                               JOptionPane.showMessageDialog(null, "You can't be in a negative or nonexistent seat, it must be a whole number above 0", "You know who ELSE makes mistakes?", JOptionPane.ERROR_MESSAGE);
                           }
                        }catch(NumberFormatException Mp){
                            JOptionPane.showMessageDialog(null, "Input a number, man", "Hey! Listen!", JOptionPane.ERROR_MESSAGE);
                        }
                    }
                });


//When user enters what movie they want in the Jtextfield does...
                /*MovieEnter.addActionListener (new ActionListener() {
                    @Override
                    //Makes sure user enters a
                    public void actionPerformed(ActionEvent e) {
                        String inputStr = MovieEnter.getText().trim();
                        String movieHolder = inputStr;
                        int gholder=0;
                        if (inputStr.isEmpty()) {
                            JOptionPane.showMessageDialog(null, "Enter a movie", "Error", JOptionPane.ERROR_MESSAGE);
                            return;
                        }
                         //Checks if any of the seats are available
                            for ( int g = list.size() - 1; g >= 0; --g) {
                                if (((Movie) list.get(g)).noSeats(seatChecker) == true) {
                                    if (((Movie) list.get(g)).title.equals(inputStr)) {
                                        for(int r=0;r<list.get(g).seatNum.length;r++){
                                            if(list.get(g).isFilled[r]==true) {
                                                JLabel availaseat = new JLabel("Available seat number: " + r);
                                                 gholder=g;
                                            }
                                        }
                                    }
                                }else if(list.get(g).noSeats(seatChecker) ==false){
                                    JOptionPane.showMessageDialog(null, "Sorry, man. That movie is full.", "Womp womp", JOptionPane.ERROR_MESSAGE);
                                }
                                else if(list.size()<=0){
                                    JOptionPane.showMessageDialog(null, "There's nothing in the system, go enter a movie in first", "Womp womp", JOptionPane.ERROR_MESSAGE);
                                }
                                else{
                                    JOptionPane.showMessageDialog(null, "Seems you didn't enter something in the system, go try again.", "Womp womp", JOptionPane.ERROR_MESSAGE);
                                }
                            }
                        peace.setVisible(true);
                        peace.add(panel2);
                        panel2.add(Yourseat);
                        panel2.add(SeatEnter);

                          //Lets users enter the seat number they want
                        int finalGholder = gholder;
                        SeatEnter.addActionListener(new ActionListener() {
                            @Override
                            public void actionPerformed(ActionEvent e) {
                                String inputStr = SeatEnter.getText().trim();
                                if (inputStr.isEmpty()) {
                                    JOptionPane.showMessageDialog(null, "Hey dude, put something here", "You didn't even try", JOptionPane.ERROR_MESSAGE);
                                    return;
                                }

                                try {
                                   int Mythracushion = 0;
                                    Mythracushion = Integer.parseInt(inputStr);
                                    if (Mythracushion > 0 && list.get(finalGholder).isFilled[Mythracushion]==true) {

                                        panel2.add(Yourage);
                                        panel2.add(AgeEnter);
                                        peace.setVisible(true);
                                        peace.add(panel2);
                                        SeatEnter.setEnabled(false);
                                        //TaxEnter.setText("");

                                        //Whenever user hits enter puts up last entry stuff, their age
                                        int finalMythracushion = Mythracushion;
                                        AgeEnter.addActionListener(new ActionListener() {
                                            @Override
                                            public void actionPerformed(ActionEvent e) {
                                                String inputStr = AgeEnter.getText().trim();
                                                if (inputStr.isEmpty()) {
                                                    JOptionPane.showMessageDialog(null, "Enter a number", "Error", JOptionPane.ERROR_MESSAGE);
                                                    return;
                                                }

                                                try {
                                                    if (inputStr.equals("c")==true || inputStr.equals("C")==true || inputStr.equals("a")==true
                                                            || inputStr.equals("A")==true || inputStr.equals("s")==true || inputStr.equals("S")==true) {

                                                        SeatEnter.setEnabled(false);
                                                        panel2.add(Yourname);
                                                        panel2.add(NameEnter);
                                                        peace.setVisible(true);
                                                        peace.add(panel2);

                                                        NameEnter.addActionListener(new ActionListener() {
                                                            @Override
                                                            public void actionPerformed(ActionEvent e) {
                                                                String urName = NameEnter.getText();
                                                                list.get(finalGholder).isFilled[finalMythracushion]=false;
                                                                list.get(finalGholder).CustomerAge[finalMythracushion]=inputStr;
                                                                JLabel finaltotal=new JLabel("");
                                                                if(inputStr.equals("c") || inputStr.equals("C")) {
                                                                    finaltotal = new JLabel("Ok "+urName+", your seat at " + movieHolder + " is seat number" + finalMythracushion +
                                                                            ", you have been registered under a child ticket. Your total is $" +(list.get(finalGholder).taxRate* 8));
                                                                }
                                                                if (inputStr.equals("a") || inputStr.equals("A")){
                                                                    finaltotal = new JLabel("Ok "+urName+", your seat at " + movieHolder + " is seat number" + finalMythracushion +
                                                                            ", you have been registered under an adult ticket. Your total is $" +(list.get(finalGholder).taxRate* 12));
                                                                }
                                                                if (inputStr.equals("c") || inputStr.equals("C")){
                                                                    finaltotal = new JLabel("Ok "+urName+", your seat at " + movieHolder + " is seat number" + finalMythracushion +
                                                                            ", you have been registered under a senior ticket. Your total is $" +(list.get(finalGholder).taxRate* 10));
                                                                }
                                                                panel2.add(finaltotal);
                                                                peace.setVisible(true);
                                                                peace.add(panel2);
                                                            }
                                                        });
                                                        //   MovieEnter.setText("");
                                                        // SeatEnter.setText("");
                                                        //  TaxEnter.setText("");

                                                    } else {
                                                        // Input is a non-positive double
                                                        JOptionPane.showMessageDialog(null, "You want to watch a movie in a theater that can only house nonexistent people? Enter a positive number.", "Error", JOptionPane.ERROR_MESSAGE);
                                                    }
                                                } catch (NumberFormatException ex) {
                                                    // Input is not a number
                                                    JOptionPane.showMessageDialog(null, "Please enter a single character ([C]hild/[A]dult/[S]enior)", "Ya Dun Goofed", JOptionPane.ERROR_MESSAGE);
                                                }
                                            }

                                        });

                                    } else {
                                        // Input is a non-positive double
                                        JOptionPane.showMessageDialog(null, "You want to watch a movie in a theater that can only house nonexistent people? Enter a positive number.", "Got Logic?", JOptionPane.ERROR_MESSAGE);
                                    }
                                } catch (NumberFormatException ex) {
                                    // Input is not a number
                                    JOptionPane.showMessageDialog(null, "That's not an acceptable answer. Please enter a whole number", "Didn't get the message?", JOptionPane.ERROR_MESSAGE);
                                }

                    /*boolean  validEntry=false;
                      while (!validEntry) {
                          if (myObj.hasNextDouble()) {
                              lifecost = myObj.nextDouble();
                              //  myObj.nextLine();
                              validEntry = true;
                          } else {
                              System.out.println("Not an answer, please enter numbers: ");
                              myObj.next();
                          }
                      }
                            }
                        });




                    }

                });*/
            }
        });
/// //////////////////////////////////////////////////////////////////////////////////////////
        //Option 3 Random ticket
        randomItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JPanel panel4 = new JPanel();
                JLabel Burlabel=new JLabel("Please enter what movie you want to watch here:");
                JLabel Allabel=new JLabel("Please enter what age you are (C/A/S):");
                JTextField comeonecomeall = new JTextField(10);
                comeonecomeall.setToolTipText("If there's a seat available, we will give you a random seat.");
                JTextField baby = new JTextField(10);
                baby.setToolTipText("Note: Only C/A/S will be accepted");
                JLabel Result =new JLabel("");
                JLabel cost =new JLabel("");
                JButton jackpot= new JButton("Get an assigned seat");

                peace.setVisible(true);
                peace.removeAll();
                peace.add(panel4);
                panel4.add(Burlabel);
                panel4.add(comeonecomeall);
                panel4.add(Allabel);
                panel4.add(baby);
                panel4.add(jackpot);
                panel4.add(Result);
                panel4.add(cost);

                //When user presses button do...

                jackpot.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        boolean idk=false;
                       String chips = comeonecomeall.getText();
                       int rando=0;
                        String DK = baby.getText();
                        if (comeonecomeall.getText().equals("") || baby.getText().equals("")) {
                            JOptionPane.showMessageDialog(null,
                                    "Enter something please", "Triforce", JOptionPane.ERROR_MESSAGE);
                        }

                        //Goes through entire Movie arraylist to try and find the movie name you entered
                        if(!(comeonecomeall.getText().equals("")) || !(baby.getText().equals(""))) {
                            for (int l = list.size() - 1; l >= 0; --l) {
                                //if it finds it then....
                                if (((Movie) list.get(l)).title.equals(chips)) {
                                    idk=true;
                                    //First makes sure that there's seats available
                                    for (int o = 0; o < list.get(l).seatNum.length; o++) {
                                        if (list.get(l).noSeats(seatChecker) == true) {
                                            //If there is then..

                                            //Loop to calculate your random ticket number, going til you get one unavailable
                                            for (int f = 0; f < 100; f--) {
                                                int index = (int) (Math.random() * list.get(l).seatNum.length);
                                                if (list.get(l).isFilled[index] == true) {
                                                    rando = index;
                                                    list.get(l).isFilled[index] = false;
                                                    f = 200;
                                                }
                                            }

                                            //listt(l).isFilled[rando+1]=false;


                                            //Enter your age, checks if it's c/a/s
                                            for (int a = 1; a < 100; a--) {
                                                if (DK.equals("c") == true || DK.equals("C") == true
                                                        || DK.equals("a") == true || DK.equals("A") == true
                                                        || DK.equals("s") == true || DK.equals("S") == true) {
                                                    a = 200;
                                                    list.get(l).CustomerAge[rando] = DK;
                                                }
                                                //Else gives this error message and makes you try again
                                                else if (DK.equals("c") == false || DK.equals("C") == false
                                                        || DK.equals("a") == false || DK.equals("A") == false
                                                        || DK.equals("s") == false || DK.equals("S") == false || DK.equals("")) {
                                                    JOptionPane.showMessageDialog(null, "You're not a fetus, enter whether you're a (C)hild,(A)dult, or (S)enior", "Ok, Tiki", JOptionPane.ERROR_MESSAGE);
                                                    l = -10;
                                                    a=200;
                                                }
                                            }
                                            //Determines your ticket cost and what age you're registered as
                                            if (DK.equals("c") || DK.equals("C")) {
                                                cost.setText("\n That will be $" + (((1 + list.get(l).taxRate)) * 8));
                                                Result.setText("Your seat is number " + (rando + 1));
                                                list.get(l).CustomerAge[l] = "C";
                                                o = list.get(l).seatNum.length + 10;

                                            }
                                            if (DK.equals("a") || DK.equals("A")) {
                                                cost.setText("\n That will be $" + (((1 + list.get(l).taxRate)) * 12));
                                                Result.setText("Your seat is number " + (rando + 1));
                                                list.get(l).CustomerAge[l] = "A";
                                                o = list.get(l).seatNum.length + 10;

                                            }
                                            if (DK.equals("s") || DK.equals("S")) {
                                                cost.setText("\n That will be $" + (((1 + list.get(l).taxRate)) * 10));
                                                Result.setText("Your seat is number " + (rando + 1));
                                                list.get(l).CustomerAge[l] = "S";
                                                o = list.get(l).seatNum.length + 10;
                                            }

                                        }
                                        //Otherwise, error message
                                        if (list.get(l).noSeats(seatChecker) == false) {
                                            JOptionPane.showMessageDialog(null, "That movie has no more seats available, try another one", "You're too slow!", JOptionPane.ERROR_MESSAGE);
                                            l = -10;
                                            comeonecomeall.setText("");
                                            baby.setText("");
                                        }
                                        //If there's no such movie in the system produces this message
                                        if (!list.get(l).title.equals(chips) && baby.getText().equals("")) {
                                            JOptionPane.showMessageDialog(null, "Not a registered movie, try again", "Dude", JOptionPane.ERROR_MESSAGE);
                                            l = -10;
                                            comeonecomeall.setText("");
                                            baby.setText("");
                                        }
                                    }

                                }
                            }
                            if(idk==false) {
                                JOptionPane.showMessageDialog(null, "Not a registered movie, try again", "Dude", JOptionPane.ERROR_MESSAGE);
                                comeonecomeall.setText("");
                                baby.setText("");
                            }
                        }
                        idk=false;
                    }
                });
            }
        });

///    ///////////////////////////////////////////////////////////////////////////////////////////////
        //Option 4, adding in .txt files
        TxtItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //User enters their .txt file directory
                JPanel panel4 = new JPanel();
                JLabel Warning=new JLabel("WARNING! Please make sure your .txt file is in name-number of seats-tax rate-customer name/customer age format first\n");
                JLabel txtentry=new JLabel("Enter the directory path of the .txt file you want to use ");
                JTextField enterhere = new JTextField(10);
                enterhere.setToolTipText("Enter your directory here and press enter when done");
                JLabel Done =new JLabel("");
                //System.out.println("WARNING! Please make sure your .txt file is in name-number of seats-tax rate-customer name/customer age format first\n");
                //System.out.println("Enter the directory path of the .txt file you want to use ");
                peace.setVisible(true);
                peace.removeAll();
                peace.add(panel4);
                panel4.add(Warning);
                panel4.add(txtentry);
                panel4.add(enterhere);
                panel4.add(Done);

                enterhere.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        String txt = enterhere.getText();

                        try {
                            FileInputStream fstream = new FileInputStream(txt);
                            DataInputStream in = new DataInputStream(fstream);
                            BufferedReader br = new BufferedReader(new InputStreamReader(in));

                            String strLine;
                            //Stores info into strings to break apart til end of file
                            while((strLine = br.readLine()) != null) {
                                //Stores into...
                                int size=-1;
                                String[] goodStuff= new String[]{("")};
                                double daTax=0;

                                //Ignores negatives
                                if(!strLine.contains("--")) {

                                    //Part that ignores the dashes

                                    goodStuff = strLine.split("-");

                           /* for (int e = 0; e < goodStuff.length; e++) {
                                System.out.println(goodStuff[e] + ", ");
                            }*/
                                    size = 0;
                                    String leName = goodStuff[0];

                                    //An entry is just ignored if there's no seats
                                    if (Integer.parseInt(goodStuff[1]) > 0) {
                                        size = Integer.parseInt(goodStuff[1]);
                                    }
                                    daTax = Double.parseDouble(goodStuff[2]);
                                }

                                if (size > 0) {
                                    //Adds to movie arraylist if it passed the checks
                                    list.add(new Movie(goodStuff[0], new int[size], daTax, new String[size], new boolean[size], new String[size]));
                                    movieCounter[0]++;
                                    //Fills the info with blanks by default
                                    Arrays.fill(list.get(movieCounter[0]).isFilled, true);
                                    Arrays.fill(list.get(movieCounter[0]).CustomerName, " ");

                                    int Custcounter = 0;

                                    //Separates the /s into readable info, and puts it into the arraylist
                                    for (int m = 3; m < goodStuff.length; ++m) {
                                        String[] slopslop = goodStuff[m].split("/");
                                        String Nozomi = slopslop[0], Eito = slopslop[1];
                                        //for(int p=0;p< goodStuff.length;p++){
                                        if (Custcounter < list.get(movieCounter[0]).seatNum.length) {

                                            list.get(movieCounter[0]).isFilled[Custcounter] = false;
                                            list.get(movieCounter[0]).CustomerName[Custcounter] = Nozomi;
                                            if (Eito.equals("c") || Eito.equals("C") || Eito.equals("a")
                                                    || Eito.equals("A") || Eito.equals("s") || Eito.equals("S")) {
                                                list.get(movieCounter[0]).CustomerAge[Custcounter] = Eito;
                                            } else {
                                                list.get(movieCounter[0]).CustomerAge[Custcounter] = "A";
                                            }
                                            //list.get(movieCounter).setCustomerName(Nozomi);
                                            // list.get(movieCounter).setCustomerAge(Eito);
                                            // }
                                            Custcounter++;
                                        }
                                    }
                                }
                            }
                            Done.setText("Your file has been processed. Do note that any movies with 0 or less seats or bonus customers in full houses were ignored");

                            in.close();
                        } catch (IOException f) {
                            f.printStackTrace();
                            JOptionPane.showMessageDialog(null, "That is not an applicable directory, please try again", "Fail whale", JOptionPane.ERROR_MESSAGE);
                        }
                    }
                });
            }
        });
/// //////////////////////////////////////////////////////////////////////////////////////////
        //Option 5, deleting a movie from the system
        DelItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JPanel panel5 = new JPanel();
                JLabel Welcome=new JLabel("Enter the name of the movie you want to delete from the system\n");
                //JLabel del=new JLabel("Enter the directory path of the .txt file you want to use ");
                JTextField delentry = new JTextField(10);
                delentry.setToolTipText("Enter the movie name here and press enter when done");
                JLabel DDDone =new JLabel("");
                //System.out.println("WARNING! Please make sure your .txt file is in name-number of seats-tax rate-customer name/customer age format first\n");
                //System.out.println("Enter the directory path of the .txt file you want to use ");
                peace.setVisible(true);
                peace.removeAll();
                peace.add(panel5);
                panel5.add(Welcome);
                panel5.add(delentry);
                panel5.add(DDDone);


                //On press do...


                delentry.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        boolean emptyChecker=false;
                        //Assuming there's anything to delete that is or else
                        if(list.size()>0) {

                            //Asks what to delete
                            String dee= delentry.getText();

                            //Checks if it's in the system
                            // if(list.size()>=0) {
                            for (int k = list.size() - 1; k >= 0; --k) {
                                //If it is then delete
                                if (((Movie) list.get(k)).title.equals(dee)) {
                                    list.remove(k);
                                    DDDone.setText(dee+" has been removed");
                                    delentry.setText("");
                                    emptyChecker=true;
                                    movieCounter[0]--;
                                }
                            }
                            //If not then error message
                            if (emptyChecker=false){
                                JOptionPane.showMessageDialog(null, "There is not a movie in the system. Try again", "Whoops", JOptionPane.ERROR_MESSAGE);
                            }
                            emptyChecker=false;
                        }
                        //Error if no movies are in
                        else if(list.size()<=0){
                            JOptionPane.showMessageDialog(null, "There are no movies in the system. There's nothing to delete but the time you just wasted", "Whoops", JOptionPane.ERROR_MESSAGE);
                        }
                    }
                });
            }
        });
/// //////////////////////////////////////////////////////////////////////////////////////
        //Option 6, Removing an individual customer from the system
        LeetItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //User enters their deleted customer
                JPanel panel4 = new JPanel();
                JLabel Moviehere=new JLabel("Please put what movie you'd like to remove a customer from here:");
                JLabel Seathere=new JLabel("Enter the seat number you'd like to clear any customers of");
                JTextField hereMovie = new JTextField(10);
                hereMovie.setToolTipText("Enter the movie here");
                JTextField hereSeat = new JTextField(10);
                hereSeat.setToolTipText("Enter the seat here");
                JButton Enter= new JButton("Enter");
                JLabel Doubledopdone =new JLabel("");
                //System.out.println("WARNING! Please make sure your .txt file is in name-number of seats-tax rate-customer name/customer age format first\n");
                //System.out.println("Enter the directory path of the .txt file you want to use ");
                peace.setVisible(true);
                peace.removeAll();
                peace.add(panel4);
                panel4.add(Moviehere);
                panel4.add(hereMovie);
                panel4.add(Seathere);
                panel4.add(hereSeat);
                panel4.add(Enter);
                panel4.add(Doubledopdone);

                Enter.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        //Makes sure user enters in something/ it's a number
                        String lyn= hereSeat.getText().trim();
                        if(lyn.isEmpty()){
                            JOptionPane.showMessageDialog(null, "Please enter something", "Whoops", JOptionPane.ERROR_MESSAGE);

                        }
                        try{
                            boolean Darkness=false;
                            int celica=Integer.parseInt(lyn);
                            String miu=hereMovie.getText().trim();
                            if(miu.isEmpty()){
                                JOptionPane.showMessageDialog(null, "Please enter something", "Whoops", JOptionPane.ERROR_MESSAGE);
                            }
                            //If the number is more than 0 then...
                            celica--;
                            if(celica>=0) {
                                //check if the movie is in the system, if yes "erase" the seat
                                for (int g = list.size() - 1; g >= 0; g--) {
                                    if (list.get(g).title.equals(miu)) {
                                        if(celica<list.get(g).seatNum.length&& celica>=0){
                                            list.get(g).isFilled[celica]=true;
                                            list.get(g).CustomerAge[celica]="";
                                            list.get(g).CustomerName[celica]="";
                                            Doubledopdone.setText("Ok, seat number "+(celica+1)+" in "+miu+" is now available");
                                            Darkness=true;
                                        }
                                        //Errors in case seat is out of bounds, if it can't be found, or if it's not a number entered
                                        else{
                                            JOptionPane.showMessageDialog(null, "That number is out of bounds for this theater, enter another seat number", "Whoops", JOptionPane.ERROR_MESSAGE);
                                        }
                                    }
                                }
                                if(Darkness==false){
                                    JOptionPane.showMessageDialog(null, "Seems that movie isn't in the system, please enter one first", "Whoa", JOptionPane.ERROR_MESSAGE);

                                }
                            }
                            else{
                                JOptionPane.showMessageDialog(null, "We don't except negative numbers, please try again", "Whoops", JOptionPane.ERROR_MESSAGE);
                            }


                        }catch(NumberFormatException BP){
                            JOptionPane.showMessageDialog(null, "Please enter a number", "Whoops", JOptionPane.ERROR_MESSAGE);

                        }
                    }
                });

            }
        });

/// //////////////////////////////////////////////////////////////////////////////////////////
        //Option 7, Printing everything in the system
       PrintItem.addActionListener(new ActionListener() {
        @Override
         public void actionPerformed(ActionEvent e) {
            StringBuilder starterstorage= new StringBuilder();
            JPanel panel7 = new JPanel();
            JLabel Currentmovie = new JLabel("");
            JLabel CurrentmovieCalc = new JLabel("");
            JLabel ReservedMovie = new JLabel("");
            JLabel ReservedMovieCalc = new JLabel("");
            JTextArea jack = new JTextArea(80,40);
            JScrollPane bob = new JScrollPane(jack,JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,
                    JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
            jack.setLineWrap(true);
            bob.add(jack);
            bob.setViewportView(jack);
           // bob.setBounds(10,60,780,500);
            //bob.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);*/

            /*JTable j= new JTable();
            j.setValueAt("Movie",1,1);
            j.setValueAt("Seat Number",1,2);
            j.setValueAt("Availability",1,3);
            j.setValueAt("Customer name",1,4);
            j.setValueAt("Customer age",1,5);
            j.setValueAt("Tax Rate",1,6);*/

           /*for(int u=0;u<list.size();u++){
                j.setValueAt(list.get(u).title,(u+1),0);
                j.setValueAt(list.get(u).taxRate,(u+1),5);

                for(int y=0;y<list.get(u).seatNum.length;y++){
                    if(list.get(u).isFilled[y]==true){
                        j.setValueAt(y,(u+1),1);
                        j.setValueAt("Available",(u+1),2);
                    }
                    if(list.get(u).isFilled[y]==false){
                        j.setValueAt(y,(u+1),1);
                        j.setValueAt("Unavailable",(u+1),2);
                        j.setValueAt(list.get(u).CustomerName[y],(u+1),3);
                        j.setValueAt(list.get(u).CustomerAge[y],(u+1),4);
                    }
                }
            }*/
            //Saves movie arraylist to JTextarea

           for(int i=0;i<list.size();i++) {
                jack.append("\n"+(i+1)+"."+(" Movie name: ")+list.get(i).title+("\n Tax rate: ")+(list.get(i).taxRate)+("\n Available seat(s): "));
                for (int r = 0; r < list.get(i).seatNum.length; r++) {
                    //If a seat is filled
                    if (list.get(i).isFilled[r]) {
                        jack.append(String.valueOf((r+1)) + (", "));
                    }
                }
                jack.append("\nReserved seat(s): ");
                for (int p = 0; p < list.get(i).seatNum.length; p++) {
                    //If it's not
                    if (list.get(i).isFilled[p] == false) {
                        jack.append((" seat number: ")+(p+1)+(" By customer: ")+(list.get(i).CustomerName[p])+(" Age: ")+(list.get(i).CustomerAge[p]));
                    }
                }
            }
            CurrentmovieCalc.setText(String.valueOf(starterstorage));
            //CurrentmovieCalc.setText(list.toString());

            //and prints it


            peace.setVisible(true);
            peace.removeAll();

            peace.add(bob);
            peace.add(panel7);
            panel7.add(jack);


            bob.setVisible(true);
           // frame.add(bob);

            //JTextField MovieEnter = new JTextField(10);
           // MovieEnter.setToolTipText("Type in the movie's name here. Press enter whenever you're done.");
            //JTextField SeatEnter = new JTextField(10);
            //JLabel Yourseat = new JLabel("Please enter what seat number you'd like");
           // JTextField AgeEnter = new JTextField(10);
            //JLabel Yourage = new JLabel("Please enter in how old you are (C/A/S)");
            //String movieman = "";
           // double lifecost = 0;
           // int Pyracushion = 0;
            //Yourmovie.setEnabled(true);
            //Yourage.setEnabled(true);
            //.setEnabled(true);


            //Shows off the first text field and label, being entering in the movie
           // frame.setVisible(true);
           // frame.add(panel);
          //  panel.add(Currentmovie);
          //  panel.add(CurrentmovieCalc);
          //  panel.add(ReservedMovie);
            //panel.add(MovieEnter);
            //
         }
        });

        // Create an "Exit" menu item with an action listener
        MenuItem exitItem = new MenuItem("Exit");
        exitItem.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });
//Adds all of the options for the menu
        peace.setVisible(true);
        peace.add(instructions);
        fileMenu.add(newItem);
        fileMenu.add(ApplyItem);
        fileMenu.add(randomItem);
        fileMenu.add(TxtItem);
        fileMenu.add(DelItem);
        fileMenu.add(LeetItem);
        fileMenu.add(PrintItem);
        fileMenu.addSeparator();
        fileMenu.add(exitItem);
//Adds the menu itself
        menuBar.add(fileMenu);

        peace.setSize(1800, 500);
        //peace.setVisible(true);




/// /////////////////////////////////////////////////////////////////
        while (!validEntry) {
            System.out.println("Enter in the first movie's name: ");
            if (myObj.hasNextLine()) {
                daMovie = myObj.nextLine();
                validEntry=true;
            } else {
                System.out.println("That's not an answer, try again. (Enter letters/characters, and spaces should be separated with _s) ");
                myObj.nextLine();
            }
        }
        validEntry=false;
        while (!validEntry) {
            System.out.println("Enter in the first movie's tax rate: ");
            if (myObj.hasNextDouble()) {
                taxx = myObj.nextDouble();
              //  myObj.nextLine();
                validEntry = true;
            } else {
                System.out.println("Not an answer, please enter numbers: ");
                myObj.next();
            }
        }
        validEntry = false;
        while (!validEntry) {
            System.out.println("Enter in how many seats the first movie has: ");
            if (myObj.hasNextInt()) {
                Idee= myObj.nextInt();
                myObj.nextLine();
                if(Idee>0) {
                    validEntry = true;
                    list.add(0, new Movie("", new int[Idee], taxx, new String[Idee], new boolean[Idee], new String[Idee]));
                    //Makes sure all seats are available(true)
                    Arrays.fill(list.get(0).isFilled, true);
                    Arrays.fill(list.get(0).CustomerName, " ");
                    Arrays.fill(list.get(0).CustomerAge, " ");
                    list.get(0).title = daMovie;
                    list.get(movieCounter[0]).setTitle(daMovie);
                }
                else{
                    System.out.println("Dude, enter a positive.\n");
                    Idee=0;
                }
            }
          /*  else if(myObj.hasNextInt()){
                System.out.println("Not an answer, please enter whole positive numbers: ");
                myObj.next();

            }*/
           /* else if (myObj.nextInt()<0){
                System.out.println("Not an answer, please enter whole positive numbers: ");
                myObj.next();
                myObj.nextLine();
            }*/
            else {
                System.out.println("Not an answer, please enter whole positive numbers: ");
                myObj.next();
                myObj.nextLine();
            }
        }
        validEntry=false;

        /*while (true) {
            // Display message
            System.out.println("Enter in how much is the tax rate of first movie: ");
            taxx = Double.parseDouble(myObj.next());

            // Try block to check if any exception occurs
            try {
                // Parsing user input to double
                // Get off from this loop
                break;
            }
            // Catch block to handle NumberFormatException
            catch (NumberFormatException e) {
                // Print the message if exception occurred
                System.out.println(
                        "NumberFormatException occurred (enter a number)\n");
            }
        }

        while (true) {
            // Display message
            System.out.println("\nEnter in how many seats the first movie's theater has: ");
            Idee = Integer.parseInt(myObj.next());

            // Try block to check if any exception occurs
            try {
                // Parsing user input to integer
                // using the parseInt() method
                list.add(new Movie(daMovie, new int[Idee], taxx, new String[Idee], new boolean[Idee], new String[Idee]));
                //Makes sure all seats are available(true)
                Arrays.fill(list.get(0).isFilled,true);
                Arrays.fill(list.get(0).CustomerName," ");
                list.get(0).title=daMovie;
                // Get off from this loop
                break;
            }
            // Catch block to handle NumberFormatException
            catch (NumberFormatException e) {
                // Print the message if exception occurred
                System.out.println(
                        "\nNumberFormatException occurred (enter a number)\n");
            }
        }*/

/// ///////////////////////////////////////////////////////////////////////////////
        basicMenu();
        System.out.println("Enter an numbered option or -1 to quit:");
        menuOption = Integer.parseInt(myObj.next());


        //Coding for all of the options
        while (menuOption != -1) {
            switch (menuOption) {
                //first option
                case 1:
                    int x = 0;
                    //Infinite loop of asking for movies to enter

                    for (; x != -1; ++x) {
                        //counter for moving up in the movie arraylist for later
                        movieCounter[0]++;
                        //System.out.println("Enter the name of the movie into the program: ");
                        // DX = myObj.next();
                        validEntry=false;
                        //Infinitely ask for movies to enter, catching any non-answers

                        while (!validEntry) {
                            System.out.println("Enter in the name of the movie into the program: ");
                            if (myObj2.hasNextLine()) {
                                DX=myObj2.nextLine();
                                validEntry=true;
                            } else {
                                System.out.println("That's not an answer, try again. (Enter letters/characters, and spaces should be seperated with _s) ");
                                myObj2.nextLine();
                            }
                        }
                        validEntry=false;

                        /*while (!validEntry) {
                            System.out.println("Enter the name of the movie into the program: ");
                            // Display message
                            if (myObj.hasNextLine()) {
                                DX = myObj.nextLine();
                                validEntry = true;
                            } else {
                                System.out.println("Not an answer, please enter letters and numbers, and separate spaces with _s: ");
                                myObj.next();
                            }
                        }*/
                            // Try block to check if any exception occurs
                           /* try {
                                // Parsing user input to double
                                // Get off from this loop
                                break;
                            }
                            // Catch block to handle NumberFormatException
                            catch (NumberFormatException e) {
                                // Print the message if exception occurred
                                System.out.println(
                                        "\nNumberFormatException occurred (enter a number)\n");
                            }*/

                        validEntry=false;
                        //System.out.println("Enter in how much is the tax rate of first movie: ");
                        // taxx = Double.parseDouble(myObj.next());
                        //Infinitely ask for tax rates, catching any non-answers
                        while (!validEntry) {
                            System.out.println("Enter in how much is the tax rate of first movie: ");
                            if (myObj2.hasNextDouble()) {
                                taxx = myObj2.nextDouble();
                                myObj2.nextLine();
                                validEntry = true;
                            } else {
                                System.out.println("Not an answer, please enter numbers: ");
                                myObj2.next();
                            }
                        }
                            // Try block to check if any exception occurs
                            /*try {
                                // Parsing user input to integer
                                // using the parseInt() method
                                // Get off from this loop
                                break;
                            }
                            // Catch block to handle NumberFormatException
                            catch (NumberFormatException e) {
                                // Print the message if exception occurred
                                System.out.println(
                                        "\nNumberFormatException occurred (enter a number)\n");
                            }*/


                        validEntry=false;
                        //Infinitely asks for numbers of seats in the theater, catch any non-answers
                        while (!validEntry) {
                            System.out.println("Enter in how many seats the movie's theater has: ");
                            if(myObj2.hasNextInt()){
                                Iddd = myObj2.nextInt();
                                myObj2.nextLine();
                              //  myObj2.nextLine();
                                if(Iddd>0){
                                    validEntry=true;
                                }
                                else{
                                    System.out.println("You want to watch a movie for a nonexistent theater? Try again.\n ");
                                }
                            }
                            else{
                                System.out.println("Not an answer, please enter numbers: ");
                                myObj2.next();
                               // myObj.nextLine();
                            }
                            // Try block to check if any exception occurs
                            /*try {
                                // Parsing user input to integer
                                // using the parseInt() method
                                // Get off from this loop
                                break;
                            }
                            // Catch block to handle NumberFormatException
                            catch (NumberFormatException e) {
                                // Print the message if exception occurred
                                System.out.println(
                                        "\nNumberFormatException occurred (enter a number)\n");
                            }*/
                        }
                        validEntry=false;
                        //System.out.println("Enter in how many seats the movie's theater has: ");
                        // Iddd = Integer.parseInt(myObj.next());

                        //Makes a new entry in the movie arraylist, all bits of logic depend on the number of seats
                        list.add(movieCounter[0],new Movie(DX+"", new int[Iddd], taxx, new String[Iddd], new boolean[Iddd], new String[Iddd]));

                        // list.add(new Movie(new String, new int[Iddd], taxx, new String[Iddd], new boolean[Iddd], new String[Iddd]));

                        // list.get(movieCounter).setTitle(DX);

                        //Makes sure that the new movie's seats are all available by default
                        Arrays.fill(list.get(movieCounter[0]).getIsFilled(),true);
                        //Makes sure names are blank by default
                        Arrays.fill(list.get(movieCounter[0]).CustomerName," ");
                        //And all the customer's ages
                        Arrays.fill(list.get(movieCounter[0]).CustomerAge," ");

                        // list.get(movieCounter).setTitle(DX);

                        // list.get(movieCounter).setTitle(DX);
                        // list.get(0).setTitle(daMovie);

                        //Asks if user wants to keep entering in movies, catches any non-answers
                        while (!validEntry) {
                            System.out.println("Do you want to continue entering in movies? (enter -1 if not, enter any other number if yes): ");
                            if (myObj.hasNextInt()) {
                                answer = myObj.nextInt();
                                validEntry = true;
                            } else {
                                System.out.println("Not an answer, please enter numbers: ");
                                myObj.next();
                            }
                        }
                        // System.out.println("Do you want to continue entering in movies? (enter -1 if not, enter any other number if yes): ");
                        // int answer = myObj.nextInt();

                        if (answer == -1) {
                            //If yes, breaks loop
                            x = -2;
                            System.out.println("------------------------------------- ");
                            basicMenu();
                            System.out.println("Enter an numbered option or -1 to quit:");
                            menuOption = Integer.parseInt(myObj.next());
                        }
                    }

                    //Prints everything
                    for (int y = 0; y < list.size(); ++y) {
                        list.get(y).starterPrint();
                    }
                    break;
/////////////////////////////////////////////////////////////////////////////////////////////////////
                //Option 2
                case 2:
                    boolean leerror=false;

                    // System.out.println("Enter the name of the movie you wish to reserve for: ");
                    // String zeanswer = myObj.next();



                  //Makes sure you entered a valid input for what Movie you want to reserve a spot, stores input if it is
                    validEntry=false;
                        while (!validEntry) {
                            System.out.println("Enter the name of the movie you wish to reserve for: ");
                            if (myObj3.hasNextLine()) {
                               zeanswer = myObj3.nextLine();
                                validEntry = true;
                            } else {
                                System.out.println("That's not an answer, try again. (Enter letters/characters) ");
                                myObj3.nextLine();
                            }
                        }
                        validEntry=false;
                        //Checks if that Movie is available or not
                        for ( int g = list.size() - 1; g >= 0; --g) {
                            //Makes full error message only pop up once

                            //If it finds it and there's seats available then...
                            if (((Movie) list.get(g)).noSeats(seatChecker) == true) {
                                if (((Movie) list.get(g)).title.equals(zeanswer)) {
                                    list.get(g).idkMan();

                                    //Asks for what seat number you'd like, looping til valid entry is permitted
                                    while (!validEntry) {
                                        System.out.println("\nEnter what number seat you'd like to reserve (must be more than 0 and whole number and must be a number available in the theater): ");
                                        if (myObj3.hasNextInt()) {
                                            zeekeeper = myObj3.nextInt() - 1;
                                            myObj3.nextLine();

                                            //Makes sure the seat number isn't a negative or taken seat or else loops back around

                                            if (zeekeeper >= 0) {
                                                if(list.get(g).seatNum.length>zeekeeper && list.get(g).isFilled[zeekeeper]==true) {
                                                    leerror=true;
                                                    validEntry = true;
                                                }
                                                else if(list.get(g).seatNum.length<zeekeeper){
                                                    System.out.println("\nSorry, we don't have that number of seat available. Try again");
                                                }
                                            } else if (zeekeeper < 0 || list.get(g).isFilled[zeekeeper]==false) {
                                                System.out.println("\nPlease enter a whole number and make sure it isn't taken!\n ");
                                            }
                                            //If user enters non answer then outputs this and asks again
                                        } else {
                                            System.out.println("Not an answer, please enter numbers: ");
                                            myObj3.next();
                                        }
                                    }
                                    validEntry = false;
                                    //Infinitely ask for whole numbers
                                /*while (true) {
                                    // Display message
                                    //Whatever seat number you're entered under will dictate later logic for the Movie arraylist
                                    System.out.println("\nEnter what number seat you'd like to reserve: ");
                                    zeekeeper = Integer.parseInt(myObj.next()) - 1;
                                    if (zeekeeper < 0) {
                                        System.out.println("\nPlease enter a whole number!\n ");
                                        System.out.println("\nEnter what number seat you'd like to reserve: ");
                                        zeekeeper = Integer.parseInt(myObj.next());
                                    }

                                    // Try block to check if any exception occurs
                                    try {*/
                                    // Parsing user input to double
                                    // Get off from this loop

                                    //Saves name user inputs
                                    ((Movie) list.get(g)).isFilled[zeekeeper] = false;
                                    System.out.println("\nWhat name would you like to be reserved under?");
                                    String urName = myObj3.nextLine();
                                    ((Movie) list.get(g)).CustomerName[zeekeeper] = urName;
                                    System.out.println("\n Then you will be reserved under " + urName + "!");

                                    //Asks for acceptable age til user enters obliges
                                    System.out.println("\nWhat age are you? (C,A,S)");
                                    DK = myObj3.next();
                                    myObj3.nextLine();

                                    //Enter your age,checks if it's c/a/s
                                    for (int a = 1; a < 100; a--) {
                                        if (DK.equals("c") == true || DK.equals("C") == true
                                                || DK.equals("a") == true || DK.equals("A") == true
                                                || DK.equals("s") == true || DK.equals("S") == true) {
                                            a = 200;
                                            list.get(g).CustomerAge[zeekeeper] = DK;
                                        }
                                        //Else gives this error message and makes you try again
                                        else if (DK.equals("c") == false || DK.equals("C") == false
                                                || DK.equals("a") == false || DK.equals("A") == false
                                                || DK.equals("s") == false || DK.equals("S") == false) {
                                            System.out.println("That is not an accepted answer, please enter your age:(C,A,S)");
                                            DK = myObj3.next();
                                            myObj3.nextLine();
                                        }
                                    }
                                    //Determines your ticket cost and what age you're registered as
                                    if (DK.equals("c") || DK.equals("C")) {
                                        System.out.println("\n That will be $" + (((1 + (list.get(g).taxRate)) * 8)));
                                        list.get(g).CustomerAge[zeekeeper] = "C";
                                        leerror=true;
                                    }
                                    if (DK.equals("a") || DK.equals("A")) {
                                        System.out.println("\n That will be $" + (((1 + list.get(g).taxRate)) * 12));
                                        list.get(g).CustomerAge[zeekeeper] = "A";
                                        leerror=true;
                                    }
                                    if (DK.equals("s") || DK.equals("S")) {
                                        System.out.println("\n That will be $" + (((1 + list.get(g).taxRate)) * 10));
                                        list.get(g).CustomerAge[zeekeeper] = "S";
                                        leerror=true;
                                    }
                                    System.out.println("--------------------------------------------------\n");

                                   // break;
                                }
                                // Catch block to handle NumberFormatException
                                   /* catch (NumberFormatException e) {
                                        // Print the message if exception occurred
                                        System.out.println(
                                                "NumberFormatException occurred (enter a whole number)\n");
                                    }*/


                            }

                            //Otherwise just prints a generic message
                            else {
                                System.out.println("\nThat's not a movie registered in the system!");
                            }
                       // }

                    }
                    //Checks if there's no seats left, if so....
                            if (leerror == false) {
                    System.out.println("Sorry, that movie is full, please try another movie.");
                }

                    //Calls back the menu as part of the infinite loop
                    basicMenu();
                    System.out.println("Enter an numbered option or -1 to quit:");
                    menuOption = Integer.parseInt(myObj.next());
                    break;

/// ////////////////////////////////////////////////////////////////////////////////////////////////
                //Third option
                case 3:
                    //Random ticket = new Random();
                    System.out.println("Enter the name of the movie you wish to buy your ticket for: ");
                    zeanswer = myObj4.nextLine();

                    //Goes through entire Movie arraylist to try and find the movie name you entered
                    for (int l = list.size() - 1; l >= 0; --l)  {
                        //if it finds it then....
                        if (((Movie) list.get(l)).title.equals(zeanswer)) {
                            //First makes sure that there's seats available
                            for (int o = 0; o < list.get(l).seatNum.length; o++) {
                                if (list.get(l).noSeats(seatChecker) == true) {
                                    //If there is then...
                                    list.get(l).idkMan();

                                    //Loop to calculate your random ticket number, going til you get one unavailable
                                    for (int f = 0; f < 100; f--) {
                                        int index = (int) (Math.random() * list.get(l).seatNum.length);
                                        if (list.get(l).isFilled[index] == true) {
                                            rando = index;
                                            list.get(l).isFilled[index] = false;
                                            f = 200;
                                        }
                                    }
                                    System.out.println("Your seat is number " + (rando + 1));
                                    //listt(l).isFilled[rando+1]=false;

                                    System.out.println("\nWhat age are you? (C,A,S)");
                                    DK = myObj4.next();
                                    myObj4.nextLine();
                                    //Enter your age, checks if it's c/a/s
                                    for (int a = 1; a < 100; a--) {
                                        if (DK.equals("c") == true || DK.equals("C") == true
                                                || DK.equals("a") == true || DK.equals("A") == true
                                                || DK.equals("s") == true || DK.equals("S") == true) {
                                            a = 200;
                                            list.get(l).CustomerAge[rando] = DK;
                                        }
                                        //Else gives this error message and makes you try again
                                        else if (DK.equals("c") == false || DK.equals("C") == false
                                                || DK.equals("a") == false || DK.equals("A") == false
                                                || DK.equals("s") == false || DK.equals("S") == false) {
                                            System.out.println("That is not an accepted answer, please enter your age:(C,A,S)");
                                            DK = myObj4.next();
                                            myObj4.nextLine();
                                        }
                                    }
                                    //Determines your ticket cost and what age you're registered as
                                    if (DK.equals("c") || DK.equals("C")) {
                                        System.out.println("\n That will be $" + (((1 + list.get(l).taxRate)) * 8));
                                        System.out.println("------------------------------------- ");
                                        list.get(l).CustomerAge[l] = "C";
                                        o= list.get(l).seatNum.length+10;

                                    }
                                    if (DK.equals("a") || DK.equals("A")) {
                                        System.out.println("\n That will be $" + (((1 + list.get(l).taxRate)) * 12));
                                        System.out.println("------------------------------------- ");
                                        list.get(l).CustomerAge[l] = "A";
                                        o=list.get(l).seatNum.length+10;

                                    }
                                    if (DK.equals("s") || DK.equals("S")) {
                                        System.out.println("\n That will be $" + (((1 + list.get(l).taxRate)) * 10));
                                        System.out.println("------------------------------------- ");
                                        list.get(l).CustomerAge[l] = "S";
                                        o=list.get(l).seatNum.length+10;
                                    }

                                }
                                //Otherwise, error message
                                else{
                                    System.out.println(" Sorry, there's no more seats available\n");
                                }
                                //If there's no such movie in the system produces this message
                                if (!list.get(l).title.equals(zeanswer)) {
                                    System.out.println("Sorry that's not in our system\n");
                                }
                            }

                        }
                    }

                    System.out.println("------------------------------------- ");
                    basicMenu();
                    System.out.println("Enter an numbered option or -1 to quit:");
                    menuOption = Integer.parseInt(myObj.next());

                    break;

                    /// ///////////////////////////////////////////////////////////////////////////////////////
                //Option 4
                case 4:
                    //User enters their .txt file directory
                    System.out.println("WARNING! Please make sure your .txt file is in name-number of seats-tax rate-customer name/customer age format first\n");
                    System.out.println("Enter the directory path of the .txt file you want to use ");
                    String txt = myObj5.next();

                    try {
                        FileInputStream fstream = new FileInputStream(txt);
                        DataInputStream in = new DataInputStream(fstream);
                        BufferedReader br = new BufferedReader(new InputStreamReader(in));

                        String strLine;
                        //Stores info into strings to break apart til end of file
                        while((strLine = br.readLine()) != null) {
                            //Stores into...
                            int size=-1;
                            String[] goodStuff= new String[]{("")};
                            double daTax=0;

                            //Ignores negatives
                            if(!strLine.contains("--")) {

                                //Part that ignores the dashes

                                 goodStuff = strLine.split("-");

                           /* for (int e = 0; e < goodStuff.length; e++) {
                                System.out.println(goodStuff[e] + ", ");
                            }*/
                                 size = 0;
                                String leName = goodStuff[0];

                                //An entry is just ignored if there's no seats
                                if (Integer.parseInt(goodStuff[1]) > 0) {
                                    size = Integer.parseInt(goodStuff[1]);
                                }
                                 daTax = Double.parseDouble(goodStuff[2]);
                            }

                            if (size > 0) {
                                //Adds to movie arraylist if it passed the checks
                                list.add(new Movie(goodStuff[0], new int[size], daTax, new String[size], new boolean[size], new String[size]));
                                movieCounter[0]++;
                                //Fills the info with blanks by default
                                Arrays.fill(list.get(movieCounter[0]).isFilled, true);
                                Arrays.fill(list.get(movieCounter[0]).CustomerName, " ");

                                int Custcounter = 0;

                                //Separates the /s into readable info, and puts it into the arraylist
                                for (int m = 3; m < goodStuff.length; ++m) {
                                    String[] slopslop = goodStuff[m].split("/");
                                    String Nozomi = slopslop[0], Eito = slopslop[1];
                                    //for(int p=0;p< goodStuff.length;p++){
                                    if (Custcounter < list.get(movieCounter[0]).seatNum.length) {

                                        list.get(movieCounter[0]).isFilled[Custcounter] = false;
                                        list.get(movieCounter[0]).CustomerName[Custcounter] = Nozomi;
                                        if (Eito.equals("c") || Eito.equals("C") || Eito.equals("a")
                                                || Eito.equals("A") || Eito.equals("s") || Eito.equals("S")) {
                                            list.get(movieCounter[0]).CustomerAge[Custcounter] = Eito;
                                        } else {
                                            list.get(movieCounter[0]).CustomerAge[Custcounter] = "A";
                                        }
                                        //list.get(movieCounter).setCustomerName(Nozomi);
                                        // list.get(movieCounter).setCustomerAge(Eito);
                                        // }
                                        Custcounter++;
                                    }
                                }
                            }
                        }

                        in.close();
                        System.out.println("Entered. Please note any movies with 0 or less and bonus customers with full houses were also excluded.\n");
                    } catch (IOException e) {
                        e.printStackTrace();
                    }

                    for(int y = 0; y < list.size(); ++y) {
                        ((Movie)list.get(y)).starterPrint();
                    }

                    // System.out.println("Do you want to continue or go back to main menu? (-1 for main menu, any other number for continue):");
                    // int response = myObj.nextInt();
                    // if (response == -1) {
                    basicMenu();
                    System.out.println("Enter an numbered option or -1 to quit:");
                    menuOption = myObj.nextInt();
                    System.out.println("------------------------------------------");
                    //  break;
                    //  }
                    break;
/// //////////////////////////////////////////////////////////////////////////////////////////////////////////////
                //Option 5
                case 5:
                    //Infinitely asks for movies to delete
                    for(int b=0;b<100;b--){
                        //Assuming there's anything to delete that is or else
                        if(list.size()>0) {

                            //Asks what to delete
                            System.out.println("What movie do you want to erase?: ");
                            String dee = myObj6.nextLine();

                            //Checks if it's in the system
                            // if(list.size()>=0) {
                            for (int k = list.size() - 1; k >= 0; --k) {
                                //If it is then delete
                                if (((Movie) list.get(k)).title.equals(dee)) {
                                    list.remove(k);
                                    System.out.println(dee+ " has been removed\n ");
                                    emptyChecker=true;
                                    movieCounter[0]--;
                                }
                            }
                            //If not then error message
                            if (emptyChecker=false){
                                System.out.println("That's not a movie in the system!\n ");
                            }
                            emptyChecker=false;
                        }
                        //Error if no movies are in
                        else{
                            System.out.println("There are currently no movies in the system, please enter one in first.\n ");
                        }

                        //Asks if user wants to continue entering movies, breaks loop if no
                        System.out.println("Do you want to stop entering Movies?(yes/no)");
                        String daanswer = myObj6.nextLine();
                        // daanswercheck = Double.parseDouble(daanswer);
                        if (daanswer.equals("yes") || daanswer.equals("Yes")){
                            b=200;
                        }
                        else if (daanswer.equals("no") || daanswer.equals("No")){
                        }
                        else{
                            System.out.println("Not an answer! Now do you want to stop entering Movies?(yes/no)");
                            daanswer = myObj.next();
                            myObj.nextLine();
                        }
                    }

                    for (int y = 0; y < list.size(); ++y) {
                        ((Movie) list.get(y)).starterPrint();
                    }
                    basicMenu();
                    System.out.println("Enter an numbered option or -1 to quit:");
                    menuOption = Integer.parseInt(myObj.next());
                    break;
//////////////////////////////////////////////////////////////////////////////////////////
                //Option 6
                case 6:
                    int leet=0;

                    for(int b=0;b<100;b--){
                        boolean error=true;

                        //Asks for Movie to delete customer from
                        System.out.println("What movie do you want to erase a customer from?: ");
                        String dee = myObj7.nextLine();
                        int availacounter=0;

                        //Scans database to see if user input is in or not
                        if(list.size()>=0) {
                            for (int k = list.size() - 1; k >= 0; --k) {
                                if (((Movie) list.get(k)).title.equals(dee)) {
                                    for(int u=0;u<list.get(k).seatNum.length;u++) {
                                        if(list.get(k).isFilled[u]==false){
                                            availacounter++;
                                        }
                                    }

                                    ((Movie) list.get(k)).starterPrint();
                                    validEntry=false;

                                    //Makes sure a seat number to remove is entered. Gives error if not.
                                    while (!validEntry) {
                                        System.out.println("Enter the seat number of the customer you'd like to remove (must be within the specified range): ");

                                        if(myObj7.hasNextInt()){
                                            leet = myObj7.nextInt();
                                            myObj7.nextLine();
                                           leet --;

                                           //Checks if there's any customers to be deleted or not, otherwise produces a message and gets you out of loop
                                           if(availacounter>1) {

                                               //Makes sure user enters seat numbers in range, if so deletes customer
                                               if (list.get(k).seatNum.length > leet && leet>=0) {
                                                       list.get(k).isFilled[leet] = true;
                                                       list.get(k).CustomerName[leet] = "";
                                                       list.get(k).CustomerAge[leet] = "";
                                                       System.out.println("seat number: " + (leet + 1) + " has been removed\n ");
                                                       validEntry = true;
                                                       error=false;
                                               } else {
                                                   System.out.println("That seat number doesn't seem to be in the system\n");
                                               }
                                           }
                                           //No customers message
                                           else{
                                               System.out.println("There are no customers registered, please register some first then come back\n");
                                               validEntry=true;
                                           }

                                        }
                                        //If user enters something not allowed loops back around
                                        else{
                                            System.out.println("Not an answer, please enter whole numbers numbers: ");
                                            myObj7.next();
                                            myObj7.nextLine();
                                        }
                                    }
                                    validEntry=false;

                                }
                            }
                             if(error==true){
                                System.out.println("That's not a movie in the system!\n ");
                                error=false;
                            }
                        }
                        //No Movies to delete anything from message
                        else{
                            System.out.println("There are currently no movies in the system, please enter one in first.\n ");
                        }

                        //Breaks loop if you don't want to continue, asks for customers infinitely if you do.
                        System.out.println("Do you want to stop entering Movies?(yes/no)");
                        String daanswer = myObj7.next();
                        myObj7.nextLine();
                        // daanswercheck = Double.parseDouble(daanswer);
                        if (daanswer.equals("yes") || daanswer.equals("Yes")){
                            b=200;
                        }
                        else if (daanswer.equals("no") || daanswer.equals("No")){
                        }
                        else{
                            System.out.println("Not an answer! Now do you want to stop entering Movies?(yes/no)");
                            daanswer = myObj7.next();
                            myObj7.nextLine();
                        }
                    }

                    basicMenu();
                    System.out.println("Enter an numbered option or -1 to quit:");
                    menuOption = Integer.parseInt(myObj.next());
                    break;

/// //////////////////////////////////////////////////////////////
            //Option 7
                case 7:
                    for (int y = 0; y < list.size(); ++y) {
                        ((Movie) list.get(y)).starterPrint();
                    }
                    basicMenu();
                    System.out.println("Enter an numbered option or -1 to quit:");
                    menuOption = Integer.parseInt(myObj.next());

                    break;


                case -1:
                    break;

                default:
                    basicMenu();
                    System.out.println("\nThat's not an option! Enter an numbered option or -1 to quit:");
                    menuOption = myObj.nextInt();

            }

        }
    }
}


import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;
import java.util.Arrays;

import static java.util.Collections.list;

public class Main {
    static void basicMenu() {
        System.out.println("1. Enter in a new movie\n");
        System.out.println("2. Reserve a ticket + seat\n");
        System.out.println("3. Get a ticket (random seat)\n");
        System.out.println("4. Add movies/customers via .txt file\n");
        System.out.println("5. Remove movies/customers\n");
        System.out.println("6. Print all movies and customer info");
        System.out.println("-1. Quit\n");
    }

    static void main(String[] args) {
        Scanner myObj = new Scanner(System.in);
        ArrayList<Movie> list = new ArrayList();
        int menuOption = 777, Idee=0, Iddd=0,zeekeeper, rando=0,movieCounter=0,answer=0;
        double taxx = 0;
        String DX=" ",DK,daMovie=" ", firstAnswer = "yes", secondAnswer = "yes",zeanswer=" ";
        boolean seatChecker = true, validEntry=false;

        //System.out.println("Enter in the first movie's name: ");

        while (!validEntry) {
            System.out.println("Enter in the first movie's name: ");
            if (myObj.hasNext()) {
                daMovie = myObj.next();
                validEntry=true;
            } else {
                System.out.println("That's not an answer, try again. (Enter letters/characters, and spaces should be seperated with _s) ");
                myObj.next();
            }
        }
        validEntry=false;
        while (!validEntry) {
            System.out.println("Enter in the first movie's tax rate: ");
            if (myObj.hasNextDouble()) {
                taxx = myObj.nextDouble();
                validEntry = true;
            } else {
                System.out.println("Not an answer, please enter numbers: ");
                myObj.next();
            }
        }
        validEntry = false;
        while (!validEntry) {
            System.out.println("Enter in how many seats the first movie has: ");
            if (myObj.hasNextInt()) {
                Idee= myObj.nextInt();
                validEntry=true;
                list.add(new Movie(daMovie, new int[Idee], taxx, new String[Idee], new boolean[Idee], new String[Idee]));
                //Makes sure all seats are available(true)
                Arrays.fill(list.get(0).isFilled,true);
                Arrays.fill(list.get(0).CustomerName," ");
                list.get(0).title=daMovie;

            }
            else if(myObj.hasNextInt() && myObj.nextInt()<0){
                System.out.println("Not an answer, please enter whole positive numbers: ");
                myObj.next();

            }
            else {
                System.out.println("Not an answer, please enter whole numbers: ");
                myObj.next();
            }
        }
        validEntry=false;
        /*while (true) {
            // Display message
            System.out.println("Enter in how much is the tax rate of first movie: ");
            taxx = Double.parseDouble(myObj.next());

            // Try block to check if any exception occurs
            try {
                // Parsing user input to double
                // Get off from this loop
                break;
            }
            // Catch block to handle NumberFormatException
            catch (NumberFormatException e) {
                // Print the message if exception occurred
                System.out.println(
                        "NumberFormatException occurred (enter a number)\n");
            }
        }

        while (true) {
            // Display message
            System.out.println("\nEnter in how many seats the first movie's theater has: ");
            Idee = Integer.parseInt(myObj.next());

            // Try block to check if any exception occurs
            try {
                // Parsing user input to integer
                // using the parseInt() method
                list.add(new Movie(daMovie, new int[Idee], taxx, new String[Idee], new boolean[Idee], new String[Idee]));
                //Makes sure all seats are available(true)
                Arrays.fill(list.get(0).isFilled,true);
                Arrays.fill(list.get(0).CustomerName," ");
                list.get(0).title=daMovie;
                // Get off from this loop
                break;
            }
            // Catch block to handle NumberFormatException
            catch (NumberFormatException e) {
                // Print the message if exception occurred
                System.out.println(
                        "\nNumberFormatException occurred (enter a number)\n");
            }
        }*/

        basicMenu();
        System.out.println("Enter an numbered option or -1 to quit:");
        menuOption = Integer.parseInt(myObj.next());

        //Coding for all of the options
        while (menuOption != -1) {
            switch (menuOption) {
                //first option
                case 1:
                    int x = 0;
                    //Infinite loop of asking for movies to enter

                    for (; x != -1; ++x) {
                        //counter for moving up in the movie arraylist for later
                        movieCounter++;
                        //System.out.println("Enter the name of the movie into the program: ");
                       // DX = myObj.next();
                        validEntry=false;
                        //Infinitely ask for movies to enter, catching any non-answers
                        while (!validEntry) {
                            System.out.println("Enter the name of the movie into the program: ");
                            // Display message
                            if(myObj.hasNext()){
                                DX = myObj.next();
                                validEntry=true;
                            }
                           else{
                                System.out.println("Not an answer, please enter letters and numbers, and seperate spaces with _s: ");
                                myObj.next();
                            }
                            // Try block to check if any exception occurs
                           /* try {
                                // Parsing user input to double
                                // Get off from this loop
                                break;
                            }
                            // Catch block to handle NumberFormatException
                            catch (NumberFormatException e) {
                                // Print the message if exception occurred
                                System.out.println(
                                        "\nNumberFormatException occurred (enter a number)\n");
                            }*/
                        }
                        validEntry=false;
                        //System.out.println("Enter in how much is the tax rate of first movie: ");
                       // taxx = Double.parseDouble(myObj.next());
                        //Infinitely ask for tax rates, catching any non-answers
                        while (!validEntry) {
                            System.out.println("Enter in how much is the tax rate of first movie: ");
                            if(myObj.hasNextDouble()){
                                taxx = myObj.nextDouble();
                                validEntry=true;
                            }
                            else{
                                System.out.println("Not an answer, please enter numbers: ");
                                myObj.next();
                            }
                            // Try block to check if any exception occurs
                            /*try {
                                // Parsing user input to integer
                                // using the parseInt() method
                                // Get off from this loop
                                break;
                            }
                            // Catch block to handle NumberFormatException
                            catch (NumberFormatException e) {
                                // Print the message if exception occurred
                                System.out.println(
                                        "\nNumberFormatException occurred (enter a number)\n");
                            }*/
                        }

                        validEntry=false;
                        //Infinitely asks for numbers of seats in the theater, catch any non-answers
                        while (!validEntry) {
                            System.out.println("Enter in how many seats the movie's theater has: ");
                            if(myObj.hasNextInt()){
                                Iddd = myObj.nextInt();
                                validEntry=true;
                            }
                            else{
                                System.out.println("Not an answer, please enter numbers: ");
                                myObj.next();
                            }
                            // Try block to check if any exception occurs
                            /*try {
                                // Parsing user input to integer
                                // using the parseInt() method
                                // Get off from this loop
                                break;
                            }
                            // Catch block to handle NumberFormatException
                            catch (NumberFormatException e) {
                                // Print the message if exception occurred
                                System.out.println(
                                        "\nNumberFormatException occurred (enter a number)\n");
                            }*/
                        }
                        validEntry=false;
                        //System.out.println("Enter in how many seats the movie's theater has: ");
                       // Iddd = Integer.parseInt(myObj.next());

                        //Makes a new entry in the movie arraylist, all bits of logic depend on the number of seats

                        list.add(new Movie(new String(DX), new int[Iddd], taxx, new String[Iddd], new boolean[Iddd], new String[Iddd]));
                        //Makes sure that the new movie's seats are all available by default
                       Arrays.fill(list.get(movieCounter).getIsFilled(),true);
                       //Makes sure names are blank by default
                        Arrays.fill(list.get(movieCounter).CustomerName," ");
                        list.get(movieCounter).setTitle(DX);
                        list.get(0).setTitle(daMovie);

                        //Asks if user wants to keep entering in movies, catches any non-answers
                        while (!validEntry) {
                            System.out.println("Do you want to continue entering in movies? (enter -1 if not, enter any other number if yes): ");
                            if (myObj.hasNextInt()) {
                                answer = myObj.nextInt();
                                validEntry = true;
                            } else {
                                System.out.println("Not an answer, please enter numbers: ");
                                myObj.next();
                            }
                        }
                       // System.out.println("Do you want to continue entering in movies? (enter -1 if not, enter any other number if yes): ");
                       // int answer = myObj.nextInt();

                        if (answer == -1) {
                            //If yes, breaks loop
                            x = -2;
                            System.out.println("------------------------------------- ");
                            basicMenu();
                            System.out.println("Enter an numbered option or -1 to quit:");
                            menuOption = Integer.parseInt(myObj.next());
                        }
                    }

                    //Prints everything
                    for (int y = 0; y < list.size(); ++y) {
                        list.get(y).starterPrint();
                    }
                    break;

                //Option 2
                case 2:

                            // System.out.println("Enter the name of the movie you wish to reserve for: ");
                            // String zeanswer = myObj.next();

                            //Goes through entire Movie arraylist to try and find the movie name you entered

                            for (int g = list.size() - 1; g >= 0; --g) {
                                while (!validEntry) {
                                    System.out.println("Enter the name of the movie you wish to reserve for: ");
                                    if (myObj.hasNext()) {
                                        zeanswer = myObj.next();
                                        validEntry = true;
                                    } else {
                                        System.out.println("That's not an answer, try again. (Enter letters/characters, and spaces should be seperated with _s) ");
                                        myObj.next();
                                    }
                                }
                                validEntry=false;
                            //If it finds it then...
                            if (((Movie) list.get(g)).noSeats(seatChecker) == true) {
                                if (((Movie) list.get(g)).title.equals(zeanswer)) {
                                    list.get(g).idkMan();
                                    //Infinitely ask for whole numbers
                                    while (true) {
                                        // Display message
                                        //Whatever seat number you're entered under will dictate later logic for the Movie arraylist
                                        System.out.println("\nEnter what number seat you'd like to reserve: ");
                                        zeekeeper = Integer.parseInt(myObj.next()) - 1;
                                        if (zeekeeper < 0) {
                                            System.out.println("\nPlease enter a whole number!\n ");
                                            System.out.println("\nEnter what number seat you'd like to reserve: ");
                                            zeekeeper = Integer.parseInt(myObj.next());
                                        }

                                        // Try block to check if any exception occurs
                                        try {
                                            // Parsing user input to double
                                            // Get off from this loop
                                            ((Movie) list.get(g)).isFilled[zeekeeper] = false;
                                            System.out.println("\nWhat name would you like to be reserved under?");
                                            String urName = myObj.next();
                                            ((Movie) list.get(g)).CustomerName[zeekeeper] = urName;
                                            System.out.println("\n Then you will be reserved under " + urName + "!");
                                            System.out.println("\nWhat age are you? (C,A,S)");
                                            DK = myObj.next();
                                            //Enter your age,checks if it's c/a/s
                                            for (int a = 1; a < 100; a--) {
                                                if (DK.equals("c") == true || DK.equals("C") == true
                                                        || DK.equals("a") == true || DK.equals("A") == true
                                                        || DK.equals("s") == true || DK.equals("S") == true) {
                                                    a = 200;
                                                    list.get(g).CustomerAge[zeekeeper] = DK;
                                                }
                                                //Else gives this error message and makes you try again
                                                else if (DK.equals("c") == false || DK.equals("C") == false
                                                        || DK.equals("a") == false || DK.equals("A") == false
                                                        || DK.equals("s") == false || DK.equals("S") == false) {
                                                    System.out.println("That is not an accepted answer, please enter your age:(C,A,S)");
                                                    DK = myObj.next();
                                                }
                                            }
                                            //Determines your ticket cost and what age you're registered as
                                            if (DK.equals("c") || DK.equals("C")) {
                                                System.out.println("\n That will be $" + (((1 + (list.get(g).taxRate)) * 8)));
                                                list.get(g).CustomerAge[zeekeeper] = "C";
                                            }
                                            if (DK.equals("a") || DK.equals("A")) {
                                                System.out.println("\n That will be $" + (((1 + list.get(g).taxRate)) * 12));
                                                list.get(g).CustomerAge[zeekeeper] = "A";
                                            }
                                            if (DK.equals("s") || DK.equals("S")) {
                                                System.out.println("\n That will be $" + (((1 + list.get(g).taxRate)) * 10));
                                                list.get(g).CustomerAge[zeekeeper] = "S";
                                            }

                                            break;
                                        }
                                        // Catch block to handle NumberFormatException
                                        catch (NumberFormatException e) {
                                            // Print the message if exception occurred
                                            System.out.println(
                                                    "NumberFormatException occurred (enter a whole number)\n");
                                        }
                                    }
                                }
                            }
                            //Checks if there's no seats left, if so....
                            else if (((Movie) list.get(g)).noSeats(seatChecker) == false) {
                                System.out.println("Sorry, that movie is full, please try another movie.");
                            }
                            //Otherwise just prints a generic message
                            else {
                                System.out.println("\nThat's not a movie registered in the system!");
                            }

                        }

                    //Calls back the menu as part of the infinite loop
                    basicMenu();
                    System.out.println("Enter an numbered option or -1 to quit:");
                    menuOption = Integer.parseInt(myObj.next());
                    break;


                //Third option
                case 3:
                        //Random ticket = new Random();
                        System.out.println("Enter the name of the movie you wish to buy your ticket for: ");
                        zeanswer = myObj.next();
                        //Goes through entire Movie arraylist to try and find the movie name you entered
                    for (int l = list.size() - 1; l >= 0; --l)  {
                            //if it finds it then....
                            if (((Movie) list.get(l)).title.equals(zeanswer)) {
                                list.get(l).idkMan();
                                for(int f=0;f<100;f--){
                                    int index = (int)(Math.random() * list.get(l).seatNum.length);
                                    if(list.get(l).isFilled[index]==true){
                                        rando=index;
                                        list.get(l).isFilled[index]=false;
                                        f=200;
                                    }
                                }
                                System.out.println("Your seat is number "+(rando+1));
                                //listt(l).isFilled[rando+1]=false;

                                System.out.println("\nWhat age are you? (C,A,S)");
                                DK = myObj.next();
                                //Enter your age, checks if it's c/a/s
                                for(int a=1;a<100;a--){
                                    if (DK.equals("c") == true || DK.equals("C") == true
                                            || DK.equals("a") == true || DK.equals("A") == true
                                            || DK.equals("s") == true || DK.equals("S") == true) {
                                        a=200;
                                        list.get(l).CustomerAge[rando]=DK;
                                    }
                                    //Else gives this error message and makes you try again
                                    else if (DK.equals("c") == false || DK.equals("C") == false
                                            || DK.equals("a") == false || DK.equals("A") == false
                                            || DK.equals("s") == false || DK.equals("S") == false) {
                                        System.out.println("That is not an accepted answer, please enter your age:(C,A,S)");
                                        DK = myObj.next();
                                    }
                                }
                                //Determines your ticket cost and what age you're registered as
                                if (DK.equals("c") || DK.equals("C")) {
                                    System.out.println("\n That will be $" + (((1 + list.get(l).taxRate)) * 8));
                                    System.out.println("------------------------------------- ");
                                    list.get(l).CustomerAge[l] = "C";
                                }
                                if (DK.equals("a") || DK.equals("A")) {
                                    System.out.println("\n That will be $" + (((1 + list.get(l).taxRate)) * 12));
                                    System.out.println("------------------------------------- ");
                                    list.get(l).CustomerAge[l] = "A";
                                }
                                if (DK.equals("s") || DK.equals("S")) {
                                    System.out.println("\n That will be $" + (((1 + list.get(l).taxRate)) * 10));
                                    System.out.println("------------------------------------- ");
                                    list.get(l).CustomerAge[l] = "S";
                                }

                            }
                            else{
                                System.out.println("Sorry that's not in our system\n");
                            }
                            l=-89;
                        }
                    System.out.println("------------------------------------- ");
                    basicMenu();
                    System.out.println("Enter an numbered option or -1 to quit:");
                    menuOption = Integer.parseInt(myObj.next());

                    break;

                //Option 5
                case 5:
                    for(int b=0;b<100;b--){

                    System.out.println("What movie do you want to erase?: ");
                    String dee = myObj.next();

                            for (int k = list.size()-1 ; k >= 0; --k) {
                                if (((Movie) list.get(k)).title.equals(dee)) {
                                    list.remove(k);
                                }
                                else{
                                    System.out.println("That's no a movie in the system!\n ");
                                }
                            }


                        System.out.println("Do you want to stop entering Movies?(yes/no)");
                       String daanswer = myObj.next();
                        // daanswercheck = Double.parseDouble(daanswer);
                        if (daanswer.equals("yes") || daanswer.equals("Yes")){
                            b=200;
                        }
                        else if (daanswer.equals("no") || daanswer.equals("No")){
                        }
                        else{
                            System.out.println("Not an answer! Now do you want to stop entering Movies?(yes/no)");
                             daanswer = myObj.next();
                        }
                    }

                    for (int y = 0; y < list.size(); ++y) {
                        ((Movie) list.get(y)).starterPrint();
                    }
                    basicMenu();
                    System.out.println("Enter an numbered option or -1 to quit:");
                    menuOption = Integer.parseInt(myObj.next());
                    break;


                case 6:
                    for (int y = 0; y < list.size(); ++y) {
                        ((Movie) list.get(y)).starterPrint();
                    }
                    basicMenu();
                    System.out.println("Enter an numbered option or -1 to quit:");
                    menuOption = Integer.parseInt(myObj.next());

                    break;
                    //Option 4
                case 4:
                    System.out.println("This option is under construction");
                    /*System.out.println("Enter the directory path of the .txt file you want to use ");
                    String txt = myObj.next();

                    try {
                        FileInputStream fstream = new FileInputStream(txt);
                        DataInputStream in = new DataInputStream(fstream);
                        BufferedReader br = new BufferedReader(new InputStreamReader(in));

                        String strLine;
                        while((strLine = br.readLine()) != null) {
                            String[] goodStuff = strLine.split("-");

                            for(int m = 0; m < 4; ++m) {
                                int first = Integer.parseInt(goodStuff[0]);
                                double second = Double.parseDouble(goodStuff[1]);
                                String third = goodStuff[2];
                                String fourth = goodStuff[3];
                                if (m == 3) {
                                    list.add(new patron(first, second, third, fourth));
                                }
                            }
                        }

                        in.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }

                    for(int y = 0; y < list.size(); ++y) {
                        ((patron)list.get(y)).starterPrint();
                    }
            }*/

                    System.out.println("Do you want to continue or go back to main menu? (-1 for main menu, any other number for continue):");
                    int response = myObj.nextInt();
                    if (response == -1) {
                        basicMenu();
                        System.out.println("Enter an numbered option or -1 to quit:");
                        menuOption = myObj.nextInt();
                        break;
                    }
                    break;
                case -1:

                default:
                    basicMenu();
                    System.out.println("\nThat's not an option! Enter an numbered option or -1 to quit:");
                    menuOption = myObj.nextInt();

            }

        }
    }
}

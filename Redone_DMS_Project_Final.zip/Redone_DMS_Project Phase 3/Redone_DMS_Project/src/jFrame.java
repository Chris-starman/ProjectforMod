import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.Arrays;
import java.awt.*;
import java.awt.event.*;
import java.awt.*;
import javax.swing.*;
import javax.swing.JFrame;


public class jFrame extends JFrame {
    private JFrame frame;
    private JPanel panel;
    private JButton button;
    private JLabel label;
//Function to call the window
    public jFrame(){
        initialize();
    }

    public void initialize() {
        //Choosing how the pop-up window will look and what it'll display by default
        frame = new JFrame();
        this.frame.setTitle("DMS Project");
        this.frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        this.frame.setSize(500, 400);
        this.frame.setLocationRelativeTo(null);
        this.frame.setVisible(true);

        JPanel panel = new JPanel();
        panel.setLayout(new FlowLayout(FlowLayout.CENTER, 10, 5));
        frame.add(panel, BorderLayout.CENTER);

        Button button = new Button("Button");
    }
        private JButton createButton(){
        JButton button= new JButton("print");
        button.setFocusable(false);
        button.setToolTipText("please click here to enter your input(s)");
        button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            }
        });
           return button;
        }
public JTextField createjtextfield(){
        JTextField textField = new JTextField(10);
        textField.setFont(new Font("Arial",Font.BOLD,20));
        textField.setForeground(Color.BLUE);
        textField.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                label.setText(textField.getText());
            }
        });
        return textField;
}
public void Thing(List<Movie> k){
    StringBuilder starterstorage= new StringBuilder();
    JPanel panel7 = new JPanel();
    JLabel Currentmovie = new JLabel("");
    JLabel CurrentmovieCalc = new JLabel("");
    JLabel ReservedMovie = new JLabel("");
    JLabel ReservedMovieCalc = new JLabel("");
    JTextArea jack = new JTextArea(80,40);
    JScrollPane bob = new JScrollPane(jack,JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,
            JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
    jack.setLineWrap(true);
    bob.add(jack);
    bob.setViewportView(jack);

    // bob.setBounds(10,60,780,500);
    //bob.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);

           /* JTable j= new JTable();
            j.setValueAt("Movie",1,1);
            j.setValueAt("Seat Number",1,2);
            j.setValueAt("Availability",1,3);
            j.setValueAt("Customer name",1,4);
            j.setValueAt("Customer age",1,5);
            j.setValueAt("Tax Rate",1,6);

           / for(int u=0;u<list.size();u++){
                j.setValueAt(list.get(u).title,(u+1),0);
                j.setValueAt(list.get(u).taxRate,(u+1),5);

                for(int y=0;y<list.get(u).seatNum.length;y++){
                    if(list.get(u).isFilled[y]==true){
                        j.setValueAt(y,(u+1),1);
                        j.setValueAt("Available",(u+1),2);
                    }
                    if(list.get(u).isFilled[y]==false){
                        j.setValueAt(y,(u+1),1);
                        j.setValueAt("Unavailable",(u+1),2);
                        j.setValueAt(list.get(u).CustomerName[y],(u+1),3);
                        j.setValueAt(list.get(u).CustomerAge[y],(u+1),4);
                    }
                }
            }*/

    for(int i=0;i<k.size();i++) {
        jack.append("\n"+(i+1)+"."+(" Movie name: ")+k.get(i).title+("\n Tax rate: ")+(k.get(i).taxRate)+("\n Available seat(s): "));
        for (int r = 0; r < k.get(i).seatNum.length; r++) {
            //If a seat is filled
            if (k.get(i).isFilled[r]) {
                jack.append(String.valueOf((r + 1)) + (", "));
            }
        }
        jack.append("\nReserved seat(s): ");
        for (int p = 0; p < k.get(i).seatNum.length; p++) {
            //If it's not
            if (k.get(i).isFilled[p] == false) {
                jack.append((" seat number: ")+(p + 1)+(" By customer: ")+(k.get(i).CustomerName[p])+(" Age: ")+(k.get(i).CustomerAge[p]));
            }
        }
    }
    CurrentmovieCalc.setText(String.valueOf(starterstorage));
    //CurrentmovieCalc.setText(list.toString());


    frame.setVisible(true);
    frame.removeAll();

    panel7.add(bob,BorderLayout.PAGE_START);
    frame.add(panel7);
    panel7.add(jack);
    bob.setVisible(true);
}


}
